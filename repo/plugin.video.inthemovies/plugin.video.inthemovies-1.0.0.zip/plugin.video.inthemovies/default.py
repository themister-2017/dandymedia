# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.inthemovies/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'inthemovies'
VERSION = '1.0.0'
BASEURL = 'http://www.fullmoviesyify.com/'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR white]All Movies[/COLOR][/B]',BASEURL + 'category/all-movies/',5,ART + 'allmovies.jpg',FANART,'')
    Menu('[B][COLOR white]Action[/COLOR][/B]',BASEURL + 'category/all-movies/action/',5,ART + 'action.jpg',FANART,'')
    Menu('[B][COLOR white]Crime[/COLOR][/B]',BASEURL + 'category/all-movies/crime/',5,ART + 'crime.jpg',FANART,'')
    Menu('[B][COLOR white]Drama[/COLOR][/B]',BASEURL + 'category/all-movies/drama/',5,ART + 'drama.jpg',FANART,'')
    Menu('[B][COLOR white]Comedy[/COLOR][/B]',BASEURL + 'category/all-movies/comedy/',5,ART + 'comedy.jpg',FANART,'')
    Menu('[B][COLOR white]Thriller[/COLOR][/B]',BASEURL + 'category/all-movies/thriller/',5,ART + 'thriller.jpg',FANART,'')
    Menu('[B][COLOR white]Adventure[/COLOR][/B]',BASEURL + 'category/all-movies/adventure/',5,ART + 'adventure.jpg',FANART,'')
    Menu('[B][COLOR white]Animation[/COLOR][/B]',BASEURL + 'category/all-movies/animation/',5,ART + 'animation.jpg',FANART,'')
    Menu('[B][COLOR white]Horror[/COLOR][/B]',BASEURL + 'category/all-movies/horror/',5,ART + 'horror.jpg',FANART,'')
    Menu('[B][COLOR blue]More Genres[/COLOR][/B]','',3,ART + 'more_genres.jpg',FANART,'')
    Menu('[B][COLOR blue]Release Year[/COLOR][/B]','',4,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR blue]Search Movies[/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def years():
    Menu('[B][COLOR white]2016[/COLOR][/B]',BASEURL + 'category/all-movies/2016/',5,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]2015[/COLOR][/B]',BASEURL + 'category/all-movies/2015/',5,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]2014[/COLOR][/B]',BASEURL + 'category/all-movies/2014/',5,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]2013[/COLOR][/B]',BASEURL + 'category/all-movies/2013/',5,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]2012[/COLOR][/B]',BASEURL + 'category/all-movies/2012/',5,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]2011[/COLOR][/B]',BASEURL + 'category/all-movies/2011/',5,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]2005-2010[/COLOR][/B]',BASEURL + 'category/all-movies/2005-2010/',5,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]2000-2004[/COLOR][/B]',BASEURL + 'category/all-movies/2000-2004/',5,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]1950-1999[/COLOR][/B]',BASEURL + 'category/all-movies/1950-1999/',5,ART + 'release.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def more_genres():
    Menu('[B][COLOR white]Biography[/COLOR][/B]',BASEURL + 'category/all-movies/biography/',5,ART + 'bio.jpg',FANART,'')
    Menu('[B][COLOR white]Documentary[/COLOR][/B]',BASEURL + 'category/all-movies/documentary/',5,ART + 'docu.jpg',FANART,'')
    Menu('[B][COLOR white]Sci-fi[/COLOR][/B]',BASEURL + 'category/all-movies/sci-fi/',5,ART + 'sci_fi.jpg',FANART,'')
    Menu('[B][COLOR white]Family[/COLOR][/B]',BASEURL + 'category/all-movies/family/',5,ART + 'family.jpg',FANART,'')
    Menu('[B][COLOR white]Romance[/COLOR][/B]',BASEURL + 'category/all-movies/romance/',5,ART + 'romance.jpg',FANART,'')
    Menu('[B][COLOR white]Fantasy[/COLOR][/B]',BASEURL + 'category/all-movies/fantasy/',5,ART + 'fantasy.jpg',FANART,'')
    Menu('[B][COLOR white]History[/COLOR][/B]',BASEURL + 'category/all-movies/history/',5,ART + 'history.jpg',FANART,'')
    Menu('[B][COLOR white]Music[/COLOR][/B]',BASEURL + 'category/all-movies/music/',5,ART + 'music.jpg',FANART,'')
    Menu('[B][COLOR white]Mystery[/COLOR][/B]',BASEURL + 'category/all-movies/mystery/',5,ART + 'mystery.jpg',FANART,'')
    Menu('[B][COLOR white]Sport[/COLOR][/B]',BASEURL + 'category/all-movies/sport/',5,ART + 'sport.jpg',FANART,'')
    Menu('[B][COLOR white]War[/COLOR][/B]',BASEURL + 'category/all-movies/war/',5,ART + 'war.jpg',FANART,'')
    Menu('[B][COLOR white]Western[/COLOR][/B]',BASEURL + 'category/all-movies/western/',5,ART + 'western.jpg',FANART,'')
    Menu('[B][COLOR white]Short[/COLOR][/B]',BASEURL + 'category/all-movies/short/',5,ART + 'short.jpg',FANART,'')
    Menu('[B][COLOR white]Musical[/COLOR][/B]',BASEURL + 'category/all-movies/musical/',5,ART + 'musical.jpg',FANART,'')
    Menu('[B][COLOR white]Reality-TV[/COLOR][/B]',BASEURL + 'category/all-movies/reality-tv/',5,ART + 'reality.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_content(url):
    referer = url
    headers = {'Host': 'www.fullmoviesyify.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<a class="clip-link".+?title="(.+?)" href="(.+?)">.+?<img src="(.+?)"',re.DOTALL).findall(OPEN)
    for name,url,icon in Regex:
            name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;',' & ').replace('&#8220;','"').replace('&#8221;','"')
            Play('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    np = re.compile("<div class='wp-pagenavi'>(.+?)</div> </div>",re.DOTALL).findall(OPEN)
    np2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(np))
    for url,name in np2:
            if '&raquo;' in name:
                if 'Last &raquo;' not in name:
                    Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')




def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '?s=' + search
                Get_content(url)
    

########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def resolve(name,url,iconimage,description):
    xbmc.executebuiltin("XBMC.Notification([COLOR blue]Attempting to[/COLOR],[COLOR red]resolve Link[/COLOR] ,2000)") 
    OPEN = Open_Url(url)
    link = re.compile('<IFRAME SRC="(.+?)"',re.DOTALL).findall(OPEN)[0]
    end = Open_Url(link)
    url = re.compile('<source src="(.+?)"',re.DOTALL).findall(end)[0]

    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: more_genres()
elif mode == 4: years()
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
