# -*- coding: utf-8 -*-
#------------------------------------------------------------
# iConspire special thanks to original authors of the code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: Dandymedia
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.iconspire'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

xbmc.executebuiltin('Container.SetViewMode(500)')

YOUTUBE_CHANNEL_ID_1 = "UCyX8H5paMpxF9u9tAXW7vTQ"
YOUTUBE_CHANNEL_ID_2 = "UC9cCqWHsMabi0y1UD2M6CVg"
YOUTUBE_CHANNEL_ID_3 = "UCYDhcbkYrCIkWHzFi4HEh7Q"
YOUTUBE_CHANNEL_ID_4 = "UCbHnk8NjjHRtj-manaXbCnA"
YOUTUBE_CHANNEL_ID_5 = "UCod1WI0tgnXwsiyZUMwLQzw"
YOUTUBE_CHANNEL_ID_6 = "UCiPeMgxBzzE4pcI_Q1CxGrA"
YOUTUBE_CHANNEL_ID_7 = "UCPZiqlNI3RLyF47QTdq93GQ"
YOUTUBE_CHANNEL_ID_8 = "UCaasFoY9yYQpOfL00N3nSxg"
YOUTUBE_CHANNEL_ID_9 = "UC2lkQ3qo9nopVxGRZnND21Q"
YOUTUBE_CHANNEL_ID_10 = "UCLpf2P6JvAl3SU6LLHPa8-Q"
YOUTUBE_CHANNEL_ID_11 = "UCLmJkq6aPq-koRv0RUYNwvA"
YOUTUBE_CHANNEL_ID_12 = "UCPTOZT-H-ZXmTV4TYnKL9tA"
YOUTUBE_CHANNEL_ID_13 = "UCEOpk5s7Yd3RQXkaqv8PwDw"
YOUTUBE_CHANNEL_ID_14 = "UCqIYcGfsDIFZoe6AIcKZY9w"
YOUTUBE_CHANNEL_ID_15 = "UCrrOic-og4HzhleZqOq4L-A"
YOUTUBE_CHANNEL_ID_16 = "UCvsye7V9psc-APX6wV1twLg"
YOUTUBE_CHANNEL_ID_17 = "UChuDM_0XizfaoUc9hOspvbQ"
YOUTUBE_CHANNEL_ID_18 = "UCl0T0SKaV5rJU81F_QUCakw"
YOUTUBE_CHANNEL_ID_19 = "UC7TvL4GlQyMBLlUsTrN_C4Q"
YOUTUBE_CHANNEL_ID_20 = "UCqi3K5TwaBC9l-YQzlRG0vg"
YOUTUBE_CHANNEL_ID_21 = "UCFentsbIUPgawzv8V8Jpwvw"
YOUTUBE_CHANNEL_ID_22 = "UCeR_8eEz8qpG0z0jX8r1-wA"
YOUTUBE_CHANNEL_ID_23 = "UCittVh8imKanO_5KohzDbpg"
YOUTUBE_CHANNEL_ID_24 = "UCC3L8QaxqEGUiBC252GHy3w"
YOUTUBE_CHANNEL_ID_25 = "UCDG73pGqESS1XcEVY_0xwWw"
YOUTUBE_CHANNEL_ID_26 = "UCkVwJARa97zzXchnhyY8lwA"
YOUTUBE_CHANNEL_ID_27 = "UC-sgHphfnBhikBxyF2GbMdw"
YOUTUBE_CHANNEL_ID_28 = "UCMLkwi2X99zZ9YqphEAVMxw"
YOUTUBE_CHANNEL_ID_29 = "UCcg9c3gXb_rwyqzeCaLuHDA"
YOUTUBE_CHANNEL_ID_30 = "UCs4r4GcyfmcjhafkJ87V2IQ"
YOUTUBE_CHANNEL_ID_31 = "UC2nQYGjfe9I_tgWpqgJorUg"
YOUTUBE_CHANNEL_ID_32 = "UC4-SGp1NPjSv4dQAKXtIk7A"
YOUTUBE_CHANNEL_ID_33 = "UCD8QeNQCPuZzwklMwlq05TQ"
YOUTUBE_CHANNEL_ID_34 = "UCYtGihKsH0_wThRFB9zRAxQ"
YOUTUBE_CHANNEL_ID_35 = "UCGFU6sxly61poDlB7rBFmNA"
YOUTUBE_CHANNEL_ID_36 = "UCAhmDfQ1LfOYECmNNWgXJ7Q"
YOUTUBE_CHANNEL_ID_37 = "UCxDp_ba1zP-x5i2o14Vw6Xg"
YOUTUBE_CHANNEL_ID_38 = "UCRlICXvO4XR4HMeEB9JjDlA"
YOUTUBE_CHANNEL_ID_39 = "UCzWQYUVCpZqtN93H8RR44Qw"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Xendrius",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://yt3.ggpht.com/-07MTDNZHByw/AAAAAAAAAAI/AAAAAAAAAAA/9gjskXvjWuM/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Top Conspiracy Documentaries",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://yt3.ggpht.com/-pOXP0CnNfts/AAAAAAAAAAI/AAAAAAAAAAA/mZSyhdOZiPA/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Conspiracy Zone",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://yt3.ggpht.com/-IBehxh_7WOQ/AAAAAAAAAAI/AAAAAAAAAAA/h7g8KE03DXE/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Conspiracy News Documentary",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/-GJud3P6RxY8/AAAAAAAAAAI/AAAAAAAAAAA/gyMkXXUYCTM/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="We are Anonymous",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://yt3.ggpht.com/-l6Kp6wecCp8/AAAAAAAAAAI/AAAAAAAAAAA/D7XLPLfzlAY/s500-c-k-no/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Conspiracy Channel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://yt3.ggpht.com/-EW1v7gTxlxs/AAAAAAAAAAI/AAAAAAAAAAA/qWxQ82S4N9k/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Alltime Conspiracies",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://yt3.ggpht.com/-qFfLwq5wqQY/AAAAAAAAAAI/AAAAAAAAAAA/0vKr8Y4Dfyo/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="UFOTV The Disclosure Network",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://yt3.ggpht.com/-LzxbTMc5jx8/AAAAAAAAAAI/AAAAAAAAAAA/oJYbn_2y4ec/s500-c-k-no/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="AIO Documentaries",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://yt3.ggpht.com/-6hAdcTxpTU4/AAAAAAAAAAI/AAAAAAAAAAA/0GvgMdZzzUk/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Documentary TV",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://yt3.ggpht.com/-rK2fbGgiDzI/AAAAAAAAAAI/AAAAAAAAAAA/UUPR_jAmQnI/s500-c-k-no/photo.jpg",
        folder=True )                

    plugintools.add_item( 
        #action="", 
        title="DiscoveryDisclosure",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://yt3.ggpht.com/-5X-GguFNPto/AAAAAAAAAAI/AAAAAAAAAAA/DuUMGHSu2gM/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )    

    plugintools.add_item( 
        #action="", 
        title="Non Human Entities",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_35+"/",
        thumbnail="https://yt3.ggpht.com/-WWM0lj8yQl0/AAAAAAAAAAI/AAAAAAAAAAA/pqSvMzo4nvY/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="Just Documentary",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://yt3.ggpht.com/-YBQ4BmPw1Zs/AAAAAAAAAAI/AAAAAAAAAAA/WxaflkuLNa0/s500-c-k-no/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="David Icke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_36+"/",
        thumbnail="https://yt3.ggpht.com/-6eMfz62QtOM/AAAAAAAAAAI/AAAAAAAAAAA/MZlIr7cR7V4/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Documentary Films",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://yt3.ggpht.com/-L4qtj01rqEI/AAAAAAAAAAI/AAAAAAAAAAA/PNtLd1Y3cXA/s500-c-k-no/photo.jpg",
        folder=True ) 
		
    plugintools.add_item( 
        #action="", 
        title="Stuff They Don't Want You To Know",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://yt3.ggpht.com/-b_dYhC2SG5I/AAAAAAAAAAI/AAAAAAAAAAA/nf_GmfPp7r8/s500-c-k-no/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="The Alex Jones Channel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://yt3.ggpht.com/-DbNegouDvyU/AAAAAAAAAAI/AAAAAAAAAAA/QyDM_-5eUFc/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="BackToConstitution",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://yt3.ggpht.com/-YK7QwQqi-KE/AAAAAAAAAAI/AAAAAAAAAAA/yoc6GEsGFbY/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="ConspiracyScope",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://yt3.ggpht.com/-09O4fhWufxs/AAAAAAAAAAI/AAAAAAAAAAA/8WWyDX9aZxc/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="CorbettReport",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://yt3.ggpht.com/-18ENytFD7iY/AAAAAAAAAAI/AAAAAAAAAAA/nmL5kOfqUsw/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Disclose TruthTV",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://yt3.ggpht.com/-8QbaDb5gcG4/AAAAAAAAAAI/AAAAAAAAAAA/GLM9wpNMMkI/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="GloabalLeaks News",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://yt3.ggpht.com/-Jzps5sM1Azg/AAAAAAAAAAI/AAAAAAAAAAA/H0-_zQ5ct-A/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="THEINFOWARRIOR",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://yt3.ggpht.com/-RJ2vgMAO-JU/AAAAAAAAAAI/AAAAAAAAAAA/iZhQHkuqtm4/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Paul Joseph Watson",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://yt3.ggpht.com/-fIb6IwufvwI/AAAAAAAAAAI/AAAAAAAAAAA/Smnj7cy5o0Y/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Stefan Molyneux",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="https://yt3.ggpht.com/-9ifro6l4eVI/AAAAAAAAAAI/AAAAAAAAAAA/HSWtiPsJOlo/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Stimulator",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="https://yt3.ggpht.com/-W9RUNL_gsQk/AAAAAAAAAAI/AAAAAAAAAAA/ovi0OZh3dTE/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="the-real-institute.com Max Bliss",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="https://yt3.ggpht.com/-ZvCIrYGhC6Q/AAAAAAAAAAI/AAAAAAAAAAA/vOR-Fj4BSwE/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Thetruthergirls",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://yt3.ggpht.com/-2hIi6oGk6Zw/AAAAAAAAAAI/AAAAAAAAAAA/W5XLBr_Y_r4/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Up2space",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://yt3.ggpht.com/-rTKnQ3p1xDc/AAAAAAAAAAI/AAAAAAAAAAA/ebNcMDQV7KU/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="TheWikiLeaksChannel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="https://yt3.ggpht.com/-42T6jzDZkQQ/AAAAAAAAAAI/AAAAAAAAAAA/Rs5HgdIVheg/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Conspiracy News CHANNEL",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="https://yt3.ggpht.com/-yS7-VIoup5Q/AAAAAAAAAAI/AAAAAAAAAAA/q8g84pt9hB8/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="SGTreport.com",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="https://yt3.ggpht.com/-YhoSD_FT8dQ/AAAAAAAAAAI/AAAAAAAAAAA/qqAF1ePfcto/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Flat Earth Conspiracy",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="https://yt3.ggpht.com/-UrIglTuO1n4/AAAAAAAAAAI/AAAAAAAAAAA/CNVrgW-fIYA/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="CDF",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_33+"/",
        thumbnail="https://yt3.ggpht.com/-9n8dU9jpgo0/AAAAAAAAAAI/AAAAAAAAAAA/wtCxCuwsCgM/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Best Conspiracy Documentaries",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_34+"/",
        thumbnail="https://yt3.ggpht.com/-HxgkpU-MnIw/AAAAAAAAAAI/AAAAAAAAAAA/L6pijCM8_JU/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Prime Documentary",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://yt3.ggpht.com/-KgvvdpGK7Mk/AAAAAAAAAAI/AAAAAAAAAAA/lWSEc_ESYZ0/s500-c-k-no/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Documentary Channel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_37+"/",
        thumbnail="https://yt3.ggpht.com/-Dk2kcWpFWOA/AAAAAAAAAAI/AAAAAAAAAAA/X8VhVxE2vgQ/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Thoughty2",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_38+"/",
        thumbnail="https://yt3.ggpht.com/-siFDveqSFyI/AAAAAAAAAAI/AAAAAAAAAAA/gTlBgWjHkqA/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="DNews",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_39+"/",
        thumbnail="https://yt3.ggpht.com/-5vA_LOM_djE/AAAAAAAAAAI/AAAAAAAAAAA/qUeK1ESiQYI/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
run()
