# -*- coding: utf-8 -*-
import dandy, json, os, re, requests, sys, urllib2, urllib, urlresolver, xbmc, xbmcaddon, xbmcgui, xbmcplugin
# OpenELEQ: ^^ added xbmcaddon, json
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
#ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.solarmoviegw/')
#ICON = ADDON_PATH + 'icon.png'
#FANART = ADDON_PATH + 'fanart.jpg'
#PATH = 'solarmoviegw'
#VERSION = '0.0.1'
#BASEURL = 'http://solarmovie.ag'
#ART = ADDON_PATH + "resources/icons/"
# OpenELEQ: switched to using xbmcaddon-module for retrieving info about the addon (original above, edited below)
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')

SHID        = ID.replace('plugin.video.','')
ART         = ADDON_PATH + "/resources/icons/"
BASEURL     = 'http://solarmovie.ag'

def Main_menu():
    Menu('[B][COLOR white]Popular Movies[/COLOR][/B]', BASEURL + '/popular-new-movies.html', 5, ART + 'popular.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - By Genres[/COLOR][/B]', '', 3, ART + 'movgenre.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - By Year[/COLOR][/B]', '', 4, ART + 'movie_year.jpg', FANART, '')
    Menu('[B][COLOR orange]Search Movies[/COLOR][/B]', 'url', 6, ART + 'mov_search.jpg', FANART, '')
    Menu('[B][COLOR white]TV Shows[/COLOR][/B]', BASEURL + '/popular-new-tv-shows.html', 7, ART + 'tv_shows.jpg', FANART, '')
    Menu('[B][COLOR orange]Search TV Shows[/COLOR][/B]', 'url', 11, ART + 'searchtv.jpg', FANART, '')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Movie_year():
    Menu('[B][COLOR white]Movies - 2015[/COLOR][/B]', BASEURL + '/watch-movies-of-2015.html', 5, ART + 'movie_year.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - 2014[/COLOR][/B]', BASEURL + '/watch-movies-of-2014.html', 5, ART + 'movie_year.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - 2013[/COLOR][/B]', BASEURL + '/watch-movies-of-2013.html', 5, ART + 'movie_year.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - 2012[/COLOR][/B]', BASEURL + '/watch-movies-of-2012.html', 5, ART + 'movie_year.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - 2011[/COLOR][/B]', BASEURL + '/watch-movies-of-2011.html', 5, ART + 'movie_year.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - 2010[/COLOR][/B]', BASEURL + '/watch-movies-of-2010.html', 5, ART + 'movie_year.jpg', FANART, '')

def Get_Genres():
    OPEN = Open_Url('http://solarmovie.ag/')
    Regex = re.compile('<div class="sliderWrapper">(.+?)</ul>', re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>', re.DOTALL).findall(str(Regex))
    for url, name in Regex2: Menu('[B][COLOR white]%s[/COLOR][/B]' % name, BASEURL + url, 5, ART + 'movgenre.jpg', FANART, '')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<a class="coverImage" title="(.+?)" href="(.+?)">.+?<img src="(.+?)"',re.DOTALL).findall(OPEN)
    for name, url, icon in Regex: Menu('[B][COLOR white]%s[/COLOR][/B]' % name, BASEURL + url, 10, BASEURL + icon, FANART, '')
    np = re.compile('id="pager_bottom">(.+?)<div id="sidebar">',re.DOTALL).findall(OPEN)
    np2 = re.compile('<a href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(np))
    for url, name in np2:
        if '&gt;' in name: Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]', url, 5, ART + 'nextpage.jpg', FANART, '')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_shows(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<a class="coverImage" title="(.+?)" href="(.+?)">.+?<img src="(.+?)"',re.DOTALL).findall(OPEN)
    for name, url, icon in Regex: Menu('[B][COLOR white]%s[/COLOR][/B]' % name, BASEURL + url, 8, BASEURL + icon, FANART, '')
    np = re.compile('id="pager_bottom">(.+?)<div id="sidebar">',re.DOTALL).findall(OPEN)
    np2 = re.compile('<a href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(np))
    for url,name in np2:
        if '&gt;' in name: Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]', url, 5, ART + 'nextpage.jpg', FANART, '')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_seasons(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<a class="js-trigger-season inplace.+?".+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in Regex: Menu('[B][COLOR white]%s[/COLOR][/B]' % name, BASEURL + url, 9, iconimage, FANART, '')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<span class="epnomber">.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url, name in Regex: Menu('[B][COLOR white]%s[/COLOR][/B]' % name, BASEURL + url, 10, iconimage, FANART, '')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(name, url, iconimage):
    OPEN = Open_Url(url)
    Regex = re.compile('<td class="sourceNameCell">.+?<a href="(.+?)" target="_blank">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url, name2 in Regex:
        if 'watch movie' not in name2:
            if 'vidtodo.com' not in name2:
                if 'vid.ag' not in name2:
                    if 'thevideobee.to' not in name2:
                        if 'nowvideo.sx' not in name2:
                            if 'vodlocker.com' not in name2:
                                if 'estream.to' not in name2: Play('[B][COLOR white]%s[/COLOR][/B]' % name2, BASEURL + url, 100, iconimage, FANART, name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Search(query = None):
    if query and query != None and query != "": search = query.replace(' ','%20')
    else:
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()): search = keyb.getText().replace(' ','%20')
    url = BASEURL + '/movie/search/' + search + '/'
    Get_content(url)

def SearchTV():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ','+')
        url = BASEURL + '/tv/search/' + search + '/'
        Get_shows(url)

########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers = headers).text
    link = link.encode('ascii', 'ignore')
    return link

def Menu(name, url, mode, iconimage, fanart, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(fanart) + "&description=" + urllib.quote_plus(description)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
        liz.setInfo(type = "Video", infoLabels = {"Title": name, "Plot": description})
        liz.setProperty("Fanart_Image", fanart)
        ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def Play(name, url, mode, iconimage, fanart, description):
        u = sys.argv[0]+"?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(fanart) + "&description=" + urllib.quote_plus(description)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
        liz.setInfo(type = "Video", infoLabels = {"Title": name, "Plot": description})
        liz.setProperty( "Fanart_Image", fanart)
        ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetPlayerCore(): 
    try: 
        PlayerMethod = getSet("core-player") 
        if   (PlayerMethod == 'DVDPLAYER'): PlayerMeth = xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod == 'MPLAYER')  : PlayerMeth = xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod == 'PAPLAYER') : PlayerMeth = xbmc.PLAYER_CORE_PAPLAYER 
        else                              : PlayerMeth = xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth = xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def resolve(name, url, iconimage, description):
    name = description
    headers = {'User-Agent': User_Agent}
    r = requests.get(url, headers = headers, allow_redirects=False)
    url = r.headers['location'] 
    xbmc.executebuiltin("XBMC.Notification([COLOR orange]Attempting To[/COLOR],[COLOR green]Resolve Link[/COLOR] ,3000)")
    play = urlresolver.resolve(url)
    try: 
        liz = xbmcgui.ListItem(name, iconImage = 'DefaultVideo.png', thumbnailImage = iconimage)
        liz.setInfo(type = 'Video', infoLabels = {'Title': name, 'Plot': description})
        liz.setProperty('IsPlayable','true')
        xbmc.Player().play(play, liz)
    except:
        play = xbmc.Player(GetPlayerCore())
        play.play(str(url), liz)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2: 
        params = sys.argv[2] 
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'): params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2: param[splitparams[0]] = splitparams[1]
    return param

description = DESCRIPTION
fanart      = FANART
iconimage   = ICON
mode        = None
name        = NAME
params      = get_params()
query       = None
url         = BASEURL
# OpenELEQ: ^^ Added default values for url, name, iconimage, fanart, description and query

try   : url         = urllib.unquote_plus(params["url"])
except: pass
try   : name        = urllib.unquote_plus(params["name"])
except: pass
try   : iconimage   = urllib.unquote_plus(params["iconimage"])
except: pass
try   : mode        = int(params["mode"])
except: pass
try   : fanart      = urllib.unquote_plus(params["fanart"])
except: pass
try   : description = urllib.unquote_plus(params["description"])
except: pass
try   : query       = urllib.unquote_plus(params["query"])
except: pass
# OpenELEQ: ^^ Added query as param to be pulled

print str(SHID)     + ': ' + str(VERSION)
print "Mode: "      + str(mode)
print "URL: "       + str(url)
print "Name: "      + str(name)
print "IconImage: " + str(iconimage)
#########################################################

if   mode == None : Main_menu()
elif mode == 3    : Get_Genres()
elif mode == 4    : Movie_year()
elif mode == 5    : Get_content(url)
elif mode == 6    : Search(query)
elif mode == 7    : Get_shows(url)
elif mode == 8    : Get_seasons(url)
elif mode == 9    : Get_episodes(url)
elif mode == 10   : Get_links(name, url, iconimage)
elif mode == 11   : SearchTV()
elif mode == 100  : resolve(name, url, iconimage, description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))