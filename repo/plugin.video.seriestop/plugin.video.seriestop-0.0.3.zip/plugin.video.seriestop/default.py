# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os
import urlresolver
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.seriestop/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'seriestop'
VERSION = '0.0.3'
BASEURL = 'http://series-top.online/'
ART = ADDON_PATH + "resources/icons/"

def Home_Menu():
    Menu('[B][COLOR red]UK Soaps[/COLOR][/B]','',2,ART + 'soaps.jpg',FANART,'')
    Menu('[B][COLOR blue]All Shows (Newest order)[/COLOR][/B]','http://series-top.online/tv-shows',4,ART + 'newest.jpg',FANART,'')
    Menu('[B][COLOR blue]All Shows (Alphabetical)[/COLOR][/B]','http://series-top.online/tv-shows/abc',4,ART + 'alpha.jpg',FANART,'')
    Menu('[B][COLOR blue]All Shows (IMDB Rating)[/COLOR][/B]','http://series-top.online/tv-shows/imdb_rating',4,ART + 'imdb.jpg',FANART,'')
    Menu('[B][COLOR blue]Search[/COLOR][/B]','url',5,ART + 'search.jpg',FANART,'')
    OPEN = Open_Url('http://series-top.online/tv-shows')
    Regex = re.compile('<ul class="check-list filters" id="genres">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li>.+?<div class="cl-text"><a href="(.+?)">(.+?)</a></div>.+?</li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,4,ICON,FANART,'')

	
def Soaps_Menu():
    Menu('[B][COLOR red]Coronation Street[/COLOR][/B]','http://series-top.online/show/coronation-street',3,'http://thetvdb.com/banners/_cache/posters/71565-2.jpg','http://thetvdb.com/banners/fanart/original/71565-2.jpg','')
    Menu('[B][COLOR red]Eastenders[/COLOR][/B]','http://series-top.online/show/eastenders',3,'http://thetvdb.com/banners/_cache/posters/71753-2.jpg','http://thetvdb.com/banners/fanart/original/71753-7.jpg','')
    Menu('[B][COLOR red]Emmerdale[/COLOR][/B]','http://series-top.online/show/emmerdale',3,'http://thetvdb.com/banners/_cache/posters/77715-2.jpg','http://thetvdb.com/banners/fanart/original/77715-3.jpg','')
    Menu('[B][COLOR red]Casualty[/COLOR][/B]','http://series-top.online/show/casualty',3,'http://thetvdb.com/banners/_cache/posters/71756-4.jpg','http://thetvdb.com/banners/fanart/original/71756-2.jpg','')
    Menu('[B][COLOR red]Holby City[/COLOR][/B]','http://series-top.online/show/holby-city',3,'http://thetvdb.com/banners/_cache/posters/77235-1.jpg','http://thetvdb.com/banners/fanart/original/77235-3.jpg','')
    Menu('[B][COLOR red]Hollyoaks[/COLOR][/B]','http://series-top.online/show/hollyoaks',3,'http://thetvdb.com/banners/_cache/posters/78006-1.jpg','http://thetvdb.com/banners/fanart/original/78006-1.jpg','')
    Menu('[B][COLOR red]Doctors[/COLOR][/B]','http://series-top.online/show/doctors',3,'http://thetvdb.com/banners/_cache/posters/83729-2.jpg','http://thetvdb.com/banners/fanart/original/83729-1.jpg','')
    Menu('[B][COLOR red]Home & Away[/COLOR][/B]','http://series-top.online/show/home-away',3,'http://thetvdb.com/banners/_cache/posters/71890-2.jpg','http://thetvdb.com/banners/fanart/original/71890-1.jpg','')
    Menu('[B][COLOR red]Neighbours[/COLOR][/B]','http://series-top.online/show/neighbours',3,'http://thetvdb.com/banners/_cache/posters/76719-2.jpg','http://thetvdb.com/banners/fanart/original/76719-2.jpg','')
	
def Shows_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="home-box">.+?<a href="(.+?)".+?style="background-image:url\(\'(.+?)\'\)" title="(.+?)"></a>	',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('amp;','').replace('w=120&h=180&zc=3','w=240&h=360&zc=1')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,FANART,'')
    np = re.compile('<li><a href="(.+?)">(.+?)</a></li> ',re.DOTALL).findall(OPEN)
    for url,name in np:
            if '&raquo;' in name:
                    Menu('Next Page>>>',url,4,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Main_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<a title=.+?data-original="(.+?)".+?title=".+?" href="(.+?)" class="episode">(.+?)</a><br />',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            icon = icon.replace('amp;','').replace('w=170&h=115&zc=1','w=340&h=230&zc=1')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')
		
	
def Second_Menu(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div id="link_list"(.+?)<div class="clear"></div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a class="embed-selector" href="(.+?)".+?<strong>(.+?)</strong>',re.DOTALL).findall(str(Regex))
    for url,name2 in Regex2:
            #if 'vidspot.net' in name:
                #Play(name,url,100,iconimage,FANART,'')
            #if 'vodlocker.com' in name:
                #Play(name,url,100,iconimage,FANART,'')
            #if 'vidzi.tv' in name:
                #Play(name,url,100,iconimage,FANART,'')
            #if 'vidto.me' in name:
                #Play(name,url,100,iconimage,FANART,'')
            #if 'streamin.to' in name:
                #Play(name,url,100,iconimage,FANART,'')
            #if 'thevideo.me' in name:
                #Play(name,url,100,iconimage,FANART,'')
            #if 'allmyvideos.net' in name:
                #Play(name,url,100,iconimage,FANART,'')
            if urlresolver.HostedMediaFile(url):
                    Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','-')
                url = BASEURL + 'show/' + search
                OPEN = Open_Url(url)
                Regex = re.compile('<div class="post_show_left">.*?<a href="(.*?)" rel="bookmark" title="(.*?)">.*?<img class="img_poster" src="(.*?)" alt=".*?"/>',re.DOTALL).findall(OPEN)
                for url, name, icon in Regex:
                        icon = icon.replace('amp;','').replace('w=120&h=180','w=240&h=360')
                        Menu(name,url,3,icon,FANART,'')
    
                
    

	########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    name = description
    OPEN = Open_Url(url)
    xbmc.executebuiltin("XBMC.Notification([COLOR blue]Attempting[/COLOR],[COLOR red]To Resolve Link[/COLOR] ,2000)") 
    play=urlresolver.resolve(url)
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Home_Menu()
elif mode == 1 : Second_Menu(name,url)
elif mode == 2 : Soaps_Menu()
elif mode == 3 : Main_Menu(url)
elif mode == 4 : Shows_Menu(url)
elif mode == 5 : Search()
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
