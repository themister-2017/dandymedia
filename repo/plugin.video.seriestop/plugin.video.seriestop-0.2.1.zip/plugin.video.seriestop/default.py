# -*- coding: utf-8 -*-
import urllib2 , urllib , xbmcgui , xbmcplugin , xbmc , re , sys , os , dandy
import urlresolver
import requests
oo000 = requests . session ( )
ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
oOOo = xbmc . translatePath ( 'special://home/addons/plugin.video.seriestop/' )
O0 = oOOo + 'icon.png'
o0O = oOOo + 'fanart.jpg'
iI11I1II1I1I = 'seriestop'
oooo = '0.2.1'
iIIii1IIi = 'http://series-top.com/'
o0OO00 = oOOo + "resources/icons/"
if 78 - 78: i11i . oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( '[B][COLOR red]UK Soaps[/COLOR][/B]' , '' , 2 , o0OO00 + 'soaps.jpg' , o0O , '' )
 i1I11i ( '[B][COLOR blue]All Shows (Newest order)[/COLOR][/B]' , iIIii1IIi + 'tv-shows' , 4 , o0OO00 + 'newest.jpg' , o0O , '' )
 i1I11i ( '[B][COLOR blue]All Shows (Alphabetical)[/COLOR][/B]' , iIIii1IIi + 'tv-shows/abc' , 4 , o0OO00 + 'alpha.jpg' , o0O , '' )
 i1I11i ( '[B][COLOR blue]All Shows (IMDB Rating)[/COLOR][/B]' , iIIii1IIi + 'tv-shows/imdb_rating' , 4 , o0OO00 + 'imdb.jpg' , o0O , '' )
 i1I11i ( '[B][COLOR blue]Search[/COLOR][/B]' , 'url' , 5 , o0OO00 + 'search.jpg' , o0O , '' )
 OoOoOO00 = I11i ( iIIii1IIi + 'tv-shows' )
 O0O = re . compile ( '/tv-tags/(.+?)>' , re . DOTALL ) . findall ( OoOoOO00 )
 for Oo in O0O :
  Oo = Oo . replace ( '"' , '' ) . replace ( '\'' , '' )
  I1ii11iIi11i = Oo
  I1ii11iIi11i = I1ii11iIi11i . replace ( '-' , ' ' ) . title ( )
  i1I11i ( '[B][COLOR white]%s[/COLOR][/B]' % I1ii11iIi11i , iIIii1IIi + 'tv-tags/%s' % Oo , 4 , O0 , o0O , '' )
  if 48 - 48: oO0o / OOooOOo / I11iIi1I / IiiIII111iI
def I11i ( url ) :
 IiII = { }
 IiII [ 'User-Agent' ] = ii
 iI1Ii11111iIi = oo000 . get ( url , headers = IiII ) . text
 iI1Ii11111iIi = iI1Ii11111iIi . encode ( 'ascii' , 'ignore' )
 return iI1Ii11111iIi
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 41 - 41: I1II1
 if 100 - 100: iII1iII1i1iiI % iiIIIII1i1iI % iiI11iii111 % i1I1Ii1iI1ii
def i1I11i ( name , url , mode , iconimage , fanart , description ) :
 II1iI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 i1iIii1Ii1II = True
 i1I1Iiii1111 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1Iiii1111 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I1Iiii1111 . setProperty ( "Fanart_Image" , fanart )
 i1iIii1Ii1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1iI , listitem = i1I1Iiii1111 , isFolder = True )
 return i1iIii1Ii1II
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 22 - 22: OOo000 . O0I11i1i11i1I
def Iiii ( ) :
 i1I11i ( '[B][COLOR red]Coronation Street[/COLOR][/B]' , iIIii1IIi + 'show/coronation-street' , 3 , 'http://thetvdb.com/banners/_cache/posters/71565-2.jpg' , 'http://thetvdb.com/banners/fanart/original/71565-2.jpg' , '' )
 i1I11i ( '[B][COLOR red]Eastenders[/COLOR][/B]' , iIIii1IIi + 'show/eastenders' , 3 , 'http://thetvdb.com/banners/_cache/posters/71753-2.jpg' , 'http://thetvdb.com/banners/fanart/original/71753-7.jpg' , '' )
 i1I11i ( '[B][COLOR red]Emmerdale[/COLOR][/B]' , iIIii1IIi + 'show/emmerdale' , 3 , 'http://thetvdb.com/banners/_cache/posters/77715-2.jpg' , 'http://thetvdb.com/banners/fanart/original/77715-3.jpg' , '' )
 i1I11i ( '[B][COLOR red]Casualty[/COLOR][/B]' , iIIii1IIi + 'show/casualty' , 3 , 'http://thetvdb.com/banners/_cache/posters/71756-4.jpg' , 'http://thetvdb.com/banners/fanart/original/71756-2.jpg' , '' )
 i1I11i ( '[B][COLOR red]Holby City[/COLOR][/B]' , iIIii1IIi + 'show/holby-city' , 3 , 'http://thetvdb.com/banners/_cache/posters/77235-1.jpg' , 'http://thetvdb.com/banners/fanart/original/77235-3.jpg' , '' )
 i1I11i ( '[B][COLOR red]Hollyoaks[/COLOR][/B]' , iIIii1IIi + 'show/hollyoaks' , 3 , 'http://thetvdb.com/banners/_cache/posters/78006-1.jpg' , 'http://thetvdb.com/banners/fanart/original/78006-1.jpg' , '' )
 i1I11i ( '[B][COLOR red]Doctors[/COLOR][/B]' , iIIii1IIi + 'show/doctors' , 3 , 'http://thetvdb.com/banners/_cache/posters/83729-2.jpg' , 'http://thetvdb.com/banners/fanart/original/83729-1.jpg' , '' )
 i1I11i ( '[B][COLOR red]Home & Away[/COLOR][/B]' , iIIii1IIi + 'show/home-away' , 3 , 'http://thetvdb.com/banners/_cache/posters/71890-2.jpg' , 'http://thetvdb.com/banners/fanart/original/71890-1.jpg' , '' )
 i1I11i ( '[B][COLOR red]Neighbours[/COLOR][/B]' , iIIii1IIi + 'show/neighbours' , 3 , 'http://thetvdb.com/banners/_cache/posters/76719-2.jpg' , 'http://thetvdb.com/banners/fanart/original/76719-2.jpg' , '' )
 if 87 - 87: oO0o0o0ooO0oO / I1i1I - OoOoo0 % iIiiI1 % OOooO % OOoO00o
def II111iiii ( url ) :
 OoOoOO00 = I11i ( url )
 II = url
 IiII = { 'Host' : 'series-top.com' , 'User-Agent' : ii , 'Referer' : II }
 O0O = re . compile ( 'data.orig.+?/show/(.+?) ' , re . DOTALL ) . findall ( OoOoOO00 )
 for url in O0O :
  url = url . replace ( '"' , '' ) . replace ( '\'' , '' )
  I1ii11iIi11i = url
  I1ii11iIi11i = I1ii11iIi11i . split ( '/' ) [ 0 ]
  I1ii11iIi11i = I1ii11iIi11i . replace ( '-' , ' ' ) . title ( )
  i1I11i ( '[B][COLOR white]%s[/COLOR][/B]' % I1ii11iIi11i , iIIii1IIi + 'show/%s' % url , 1 , oOoOo00oOo , o0O , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 96 - 96: I111I11 . I1i1I - iIiiI1 - i1I1Ii1iI1ii
def OooO0OO ( ) :
 iiiIi = xbmc . Keyboard ( '' , 'Search' )
 iiiIi . doModal ( )
 if ( iiiIi . isConfirmed ( ) ) :
  IiIIIiI1I1 = iiiIi . getText ( ) . replace ( ' ' , '-' )
  Oo = iIIii1IIi + 'show/' + IiIIIiI1I1
  OoOoOO00 = I11i ( Oo )
  O0O = re . compile ( '<div class="post_show_left">.*?<a href="(.*?)" rel="bookmark" title="(.*?)">.*?<img class="img_poster" src="(.*?)" alt=".*?"/>' , re . DOTALL ) . findall ( OoOoOO00 )
  for Oo , I1ii11iIi11i , OoO000 in O0O :
   OoO000 = OoO000 . replace ( 'amp;' , '' ) . replace ( 'w=120&h=180' , 'w=240&h=360' )
   i1I11i ( I1ii11iIi11i , Oo , 3 , OoO000 , o0O , '' )
   if 42 - 42: O0I11i1i11i1I - I11iIi1I / i11i + oO0o0o0ooO0oO + iiIIIII1i1iI
def iIi ( name , url , mode , iconimage , fanart , description ) :
 II1iI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 i1iIii1Ii1II = True
 i1I1Iiii1111 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1Iiii1111 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I1Iiii1111 . setProperty ( "Fanart_Image" , fanart )
 i1iIii1Ii1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1iI , listitem = i1I1Iiii1111 , isFolder = False )
 return i1iIii1Ii1II
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 40 - 40: O0I11i1i11i1I . iiI11iii111 . iII1iII1i1iiI . I11iIi1I
def I11iii ( ) :
 try :
  OO0O00 = getSet ( "core-player" )
  if ( OO0O00 == 'DVDPLAYER' ) : ii1 = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( OO0O00 == 'MPLAYER' ) : ii1 = xbmc . PLAYER_CORE_MPLAYER
  elif ( OO0O00 == 'PAPLAYER' ) : ii1 = xbmc . PLAYER_CORE_PAPLAYER
  else : ii1 = xbmc . PLAYER_CORE_AUTO
 except : ii1 = xbmc . PLAYER_CORE_AUTO
 return ii1
 return True
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 57 - 57: OoOoo0 % OOooOOo
def O00 ( name , url ) :
 OoOoOO00 = I11i ( url )
 II = url
 IiII = { 'Host' : 'series-top.com' , 'User-Agent' : ii , 'Referer' : II }
 O0O = re . compile ( 'window.open\(yrstr\(\'(.+?)\'' , re . DOTALL ) . findall ( OoOoOO00 )
 for url in O0O :
  url = url . replace ( '-' , ' ' )
  url = bytearray . fromhex ( url ) . decode ( )
  i11I1 = url . split ( '//' ) [ 1 ] . replace ( 'www.' , '' )
  i11I1 = i11I1 . split ( '/' ) [ 0 ] . split ( '.' ) [ 0 ] . upper ( )
  if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   iIi ( '[B][COLOR white]%s[/COLOR][/B]' % i11I1 , url , 100 , oOoOo00oOo , o0O , name )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 8 - 8: oO0o - OOooO % oO0o - OoOoo0 * I1II1
def iI11i1I1 ( name , url , iconimage , description ) :
 name = description
 xbmc . executebuiltin ( "XBMC.Notification([COLOR blue]Attempting[/COLOR],[COLOR red]To Resolve Link[/COLOR] ,2000)" )
 o0o0OOO0o0 = urlresolver . resolve ( url )
 try :
  i1I1Iiii1111 = xbmcgui . ListItem ( name , iconImage = 'DefaultVideo.png' , thumbnailImage = iconimage )
  i1I1Iiii1111 . setInfo ( type = 'Video' , infoLabels = { 'Title' : name , 'Plot' : description } )
  i1I1Iiii1111 . setProperty ( 'IsPlayable' , 'true' )
  xbmc . Player ( ) . play ( o0o0OOO0o0 , i1I1Iiii1111 )
 except :
  o0o0OOO0o0 = xbmc . Player ( I11iii ( ) )
  o0o0OOO0o0 . play ( str ( url ) , i1I1Iiii1111 )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 84 - 84: OOooO
def iIi1ii1I1 ( url ) :
 OoOoOO00 = I11i ( url )
 II = url
 IiII = { 'Host' : 'series-top.com' , 'User-Agent' : ii , 'Referer' : II }
 O0O = re . compile ( '/show/(.+?) .+?/templates/(.+?);zc' , re . DOTALL ) . findall ( OoOoOO00 )
 for url , OoO000 in O0O :
  url = url . replace ( '"' , '' ) . replace ( '\'' , '' )
  I1ii11iIi11i = url
  I1ii11iIi11i = I1ii11iIi11i . replace ( '-' , ' ' ) . title ( )
  OoO000 = OoO000 . replace ( 'amp;' , '' ) . replace ( 'w=120&h=180' , 'w=240&h=360' ) . replace ( 'w=120&h=180' , 'w=240&h=360' )
  OoO000 = OoO000 + '|' + urllib . urlencode ( IiII )
  i1I11i ( '[B][COLOR white]%s[/COLOR][/B]' % I1ii11iIi11i , iIIii1IIi + 'show/%s' % url , 3 , iIIii1IIi + 'templates/%s' % OoO000 , o0O , '' )
 o0 = re . compile ( '<li><a href="(.+?)">(.+?)</a></li> ' , re . DOTALL ) . findall ( OoOoOO00 )
 for url , I1ii11iIi11i in o0 :
  if '&raquo;' in I1ii11iIi11i :
   i1I11i ( '[B][COLOR blue]Next Page>>>[/COLOR][/B]' , url , 4 , o0OO00 + 'nextpage.jpg' , o0O , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 9 - 9: OoOoo0 + O0I11i1i11i1I % OoOoo0 + I11iIi1I . oO0o0o0ooO0oO
def III1i1i ( ) :
 iiI1 = [ ]
 i11Iiii = sys . argv [ 2 ]
 if len ( i11Iiii ) >= 2 :
  iI = sys . argv [ 2 ]
  I1i1I1II = iI . replace ( '?' , '' )
  if ( iI [ len ( iI ) - 1 ] == '/' ) :
   iI = iI [ 0 : len ( iI ) - 2 ]
  i1 = I1i1I1II . split ( '&' )
  iiI1 = { }
  for IiIiiI in range ( len ( i1 ) ) :
   I1I = { }
   I1I = i1 [ IiIiiI ] . split ( '=' )
   if ( len ( I1I ) ) == 2 :
    iiI1 [ I1I [ 0 ] ] = I1I [ 1 ]
    if 80 - 80: iiI11iii111 - iiIIIII1i1iI
 return iiI1
 if 87 - 87: O0I11i1i11i1I / I1i1I - I11iIi1I * oO0o0o0ooO0oO / OOooOOo . oOooOoO0Oo0O
iI = III1i1i ( )
Oo = None
I1ii11iIi11i = None
oOoOo00oOo = None
iii11I111 = None
OOOO00ooo0Ooo = None
OOOooOooo00O0 = None
if 100 - 100: i11i / iiI11iii111 % OOoO00o - OOo000 / O0I11i1i11i1I
if 50 - 50: I1II1
try :
 Oo = urllib . unquote_plus ( iI [ "url" ] )
except :
 pass
try :
 I1ii11iIi11i = urllib . unquote_plus ( iI [ "name" ] )
except :
 pass
try :
 oOoOo00oOo = urllib . unquote_plus ( iI [ "iconimage" ] )
except :
 pass
try :
 iii11I111 = int ( iI [ "mode" ] )
except :
 pass
try :
 OOOO00ooo0Ooo = urllib . unquote_plus ( iI [ "fanart" ] )
except :
 pass
try :
 OOOooOooo00O0 = urllib . unquote_plus ( iI [ "description" ] )
except :
 pass
 if 34 - 34: I1II1 * IiiIII111iI % iIiiI1 * iiI11iii111 - I1II1
 if 33 - 33: i1I1Ii1iI1ii + oO0o0o0ooO0oO * iiIIIII1i1iI - iII1iII1i1iiI / O0I11i1i11i1I % OoOoo0
print str ( iI11I1II1I1I ) + ': ' + str ( oooo )
print "Mode: " + str ( iii11I111 )
print "URL: " + str ( Oo )
print "Name: " + str ( I1ii11iIi11i )
print "IconImage: " + str ( oOoOo00oOo )
if 21 - 21: iiIIIII1i1iI * oO0o % O0I11i1i11i1I * I11iIi1I
if 16 - 16: oOooOoO0Oo0O - OOoO00o * oO0o + iIiiI1
if iii11I111 == None : iI1 ( )
elif iii11I111 == 1 : O00 ( I1ii11iIi11i , Oo )
elif iii11I111 == 2 : Iiii ( )
elif iii11I111 == 3 : II111iiii ( Oo )
elif iii11I111 == 4 : iIi1ii1I1 ( Oo )
elif iii11I111 == 5 : OooO0OO ( )
elif iii11I111 == 100 : iI11i1I1 ( I1ii11iIi11i , Oo , oOoOo00oOo , OOOooOooo00O0 )
if 50 - 50: IiiIII111iI - I111I11 * OOo000 / OOoO00o + i1I1Ii1iI1ii
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
