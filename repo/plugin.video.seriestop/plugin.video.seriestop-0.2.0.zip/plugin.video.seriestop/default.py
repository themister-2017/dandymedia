# -*- coding: utf-8 -*-
import urllib2 , urllib , xbmcgui , xbmcplugin , xbmc , re , sys , os , dandy
import urlresolver
import requests
oo000 = requests . session ( )
ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
oOOo = xbmc . translatePath ( 'special://home/addons/plugin.video.seriestop/' )
O0 = oOOo + 'icon.png'
o0O = oOOo + 'fanart.jpg'
iI11I1II1I1I = 'seriestop'
oooo = '0.2.0'
iIIii1IIi = 'http://series-top.com/'
o0OO00 = oOOo + "resources/icons/"
if 78 - 78: i11i . oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( '[B][COLOR red]UK Soaps[/COLOR][/B]' , '' , 2 , o0OO00 + 'soaps.jpg' , o0O , '' )
 i1I11i ( '[B][COLOR blue]All Shows (Newest order)[/COLOR][/B]' , iIIii1IIi + 'tv-shows' , 4 , o0OO00 + 'newest.jpg' , o0O , '' )
 i1I11i ( '[B][COLOR blue]All Shows (Alphabetical)[/COLOR][/B]' , iIIii1IIi + 'tv-shows/abc' , 4 , o0OO00 + 'alpha.jpg' , o0O , '' )
 i1I11i ( '[B][COLOR blue]All Shows (IMDB Rating)[/COLOR][/B]' , iIIii1IIi + 'tv-shows/imdb_rating' , 4 , o0OO00 + 'imdb.jpg' , o0O , '' )
 i1I11i ( '[B][COLOR blue]Search[/COLOR][/B]' , 'url' , 5 , o0OO00 + 'search.jpg' , o0O , '' )
 OoOoOO00 = I11i ( iIIii1IIi + 'tv-shows' )
 O0O = re . compile ( '/tv-tags/(.+?)>' , re . DOTALL ) . findall ( OoOoOO00 )
 for Oo in O0O :
  Oo = Oo . replace ( '"' , '' ) . replace ( '\'' , '' )
  I1ii11iIi11i = Oo
  I1ii11iIi11i = I1ii11iIi11i . replace ( '-' , ' ' ) . title ( )
  i1I11i ( '[B][COLOR white]%s[/COLOR][/B]' % I1ii11iIi11i , iIIii1IIi + 'tv-tags/%s' % Oo , 4 , O0 , o0O , '' )
  if 48 - 48: oO0o / OOooOOo / I11iIi1I / IiiIII111iI
def i1I11i ( name , url , mode , iconimage , fanart , description ) :
 IiII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 iI1Ii11111iIi = True
 i1i1II = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1i1II . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1i1II . setProperty ( "Fanart_Image" , fanart )
 iI1Ii11111iIi = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiII , listitem = i1i1II , isFolder = True )
 return iI1Ii11111iIi
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
def o0oOoO00o ( ) :
 i1I11i ( '[B][COLOR red]Coronation Street[/COLOR][/B]' , iIIii1IIi + 'show/coronation-street' , 3 , 'http://thetvdb.com/banners/_cache/posters/71565-2.jpg' , 'http://thetvdb.com/banners/fanart/original/71565-2.jpg' , '' )
 i1I11i ( '[B][COLOR red]Eastenders[/COLOR][/B]' , iIIii1IIi + 'show/eastenders' , 3 , 'http://thetvdb.com/banners/_cache/posters/71753-2.jpg' , 'http://thetvdb.com/banners/fanart/original/71753-7.jpg' , '' )
 i1I11i ( '[B][COLOR red]Emmerdale[/COLOR][/B]' , iIIii1IIi + 'show/emmerdale' , 3 , 'http://thetvdb.com/banners/_cache/posters/77715-2.jpg' , 'http://thetvdb.com/banners/fanart/original/77715-3.jpg' , '' )
 i1I11i ( '[B][COLOR red]Casualty[/COLOR][/B]' , iIIii1IIi + 'show/casualty' , 3 , 'http://thetvdb.com/banners/_cache/posters/71756-4.jpg' , 'http://thetvdb.com/banners/fanart/original/71756-2.jpg' , '' )
 i1I11i ( '[B][COLOR red]Holby City[/COLOR][/B]' , iIIii1IIi + 'show/holby-city' , 3 , 'http://thetvdb.com/banners/_cache/posters/77235-1.jpg' , 'http://thetvdb.com/banners/fanart/original/77235-3.jpg' , '' )
 i1I11i ( '[B][COLOR red]Hollyoaks[/COLOR][/B]' , iIIii1IIi + 'show/hollyoaks' , 3 , 'http://thetvdb.com/banners/_cache/posters/78006-1.jpg' , 'http://thetvdb.com/banners/fanart/original/78006-1.jpg' , '' )
 i1I11i ( '[B][COLOR red]Doctors[/COLOR][/B]' , iIIii1IIi + 'show/doctors' , 3 , 'http://thetvdb.com/banners/_cache/posters/83729-2.jpg' , 'http://thetvdb.com/banners/fanart/original/83729-1.jpg' , '' )
 i1I11i ( '[B][COLOR red]Home & Away[/COLOR][/B]' , iIIii1IIi + 'show/home-away' , 3 , 'http://thetvdb.com/banners/_cache/posters/71890-2.jpg' , 'http://thetvdb.com/banners/fanart/original/71890-1.jpg' , '' )
 i1I11i ( '[B][COLOR red]Neighbours[/COLOR][/B]' , iIIii1IIi + 'show/neighbours' , 3 , 'http://thetvdb.com/banners/_cache/posters/76719-2.jpg' , 'http://thetvdb.com/banners/fanart/original/76719-2.jpg' , '' )
 if 43 - 43: O0OOo . II1Iiii1111i
 if 25 - 25: OOo000
 if 82 - 82: o000o0o00o0Oo . ii11 % oO0o0o0ooO0oO / I1i1I - OoOoo0 % OOo000
def iIiiI1 ( name , url , iconimage , description ) :
 name = description
 xbmc . executebuiltin ( "XBMC.Notification([COLOR blue]Attempting[/COLOR],[COLOR red]To Resolve Link[/COLOR] ,2000)" )
 OoOooOOOO = urlresolver . resolve ( url )
 try :
  i1i1II = xbmcgui . ListItem ( name , iconImage = 'DefaultVideo.png' , thumbnailImage = iconimage )
  i1i1II . setInfo ( type = 'Video' , infoLabels = { 'Title' : name , 'Plot' : description } )
  i1i1II . setProperty ( 'IsPlayable' , 'true' )
  xbmc . Player ( ) . play ( OoOooOOOO , i1i1II )
 except :
  OoOooOOOO = xbmc . Player ( i11iiII ( ) )
  OoOooOOOO . play ( str ( url ) , i1i1II )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 34 - 34: II1Iiii1111i % OOooOOo / I11iIi1I . ii11 + oOooOoO0Oo0O
def I1Ii ( ) :
 o0oOo0Ooo0O = xbmc . Keyboard ( '' , 'Search' )
 o0oOo0Ooo0O . doModal ( )
 if ( o0oOo0Ooo0O . isConfirmed ( ) ) :
  OO00O0O0O00Oo = o0oOo0Ooo0O . getText ( ) . replace ( ' ' , '-' )
  Oo = iIIii1IIi + 'show/' + OO00O0O0O00Oo
  OoOoOO00 = I11i ( Oo )
  O0O = re . compile ( '<div class="post_show_left">.*?<a href="(.*?)" rel="bookmark" title="(.*?)">.*?<img class="img_poster" src="(.*?)" alt=".*?"/>' , re . DOTALL ) . findall ( OoOoOO00 )
  for Oo , I1ii11iIi11i , IIIiiiiiIii in O0O :
   IIIiiiiiIii = IIIiiiiiIii . replace ( 'amp;' , '' ) . replace ( 'w=120&h=180' , 'w=240&h=360' )
   i1I11i ( I1ii11iIi11i , Oo , 3 , IIIiiiiiIii , o0O , '' )
   if 70 - 70: I1i1iI1i . I1i1iI1i - I1i1iI1i / Oo0oO0ooo * II1Iiii1111i
def I11i ( url ) :
 OoO000 = { }
 OoO000 [ 'User-Agent' ] = ii
 IIiiIiI1 = oo000 . get ( url , headers = OoO000 ) . text
 IIiiIiI1 = IIiiIiI1 . encode ( 'ascii' , 'ignore' )
 return IIiiIiI1
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 41 - 41: o00ooo0
def II ( url ) :
 OoOoOO00 = I11i ( url )
 ooOoOoo0O = url
 OoO000 = { 'Host' : 'series-top.com' , 'User-Agent' : ii , 'Referer' : ooOoOoo0O }
 O0O = re . compile ( '/show/(.+?) .+?/templates/(.+?);zc' , re . DOTALL ) . findall ( OoOoOO00 )
 for url , IIIiiiiiIii in O0O :
  url = url . replace ( '"' , '' ) . replace ( '\'' , '' )
  I1ii11iIi11i = url
  I1ii11iIi11i = I1ii11iIi11i . replace ( '-' , ' ' ) . title ( )
  IIIiiiiiIii = IIIiiiiiIii . replace ( 'amp;' , '' ) . replace ( 'w=120&h=180' , 'w=240&h=360' ) . replace ( 'w=120&h=180' , 'w=240&h=360' )
  IIIiiiiiIii = IIIiiiiiIii + '|' + urllib . urlencode ( OoO000 )
  i1I11i ( '[B][COLOR white]%s[/COLOR][/B]' % I1ii11iIi11i , iIIii1IIi + 'show/%s' % url , 3 , iIIii1IIi + 'templates/%s' % IIIiiiiiIii , o0O , '' )
 OooO0 = re . compile ( '<li><a href="(.+?)">(.+?)</a></li> ' , re . DOTALL ) . findall ( OoOoOO00 )
 for url , I1ii11iIi11i in OooO0 :
  if '&raquo;' in I1ii11iIi11i :
   i1I11i ( '[B][COLOR blue]Next Page>>>[/COLOR][/B]' , url , 4 , o0OO00 + 'nextpage.jpg' , o0O , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 35 - 35: II1Iiii1111i % I1i1I % i11i / OOooOOo
def Ii11iI1i ( name , url , mode , iconimage , fanart , description ) :
 IiII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 iI1Ii11111iIi = True
 i1i1II = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1i1II . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1i1II . setProperty ( "Fanart_Image" , fanart )
 iI1Ii11111iIi = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiII , listitem = i1i1II , isFolder = False )
 return iI1Ii11111iIi
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 82 - 82: i11i . II1Iiii1111i / Oo0ooO0oo0oO * oOooOoO0Oo0O % O0OOo % oO0o
def Oo00OOOOO ( url ) :
 OoOoOO00 = I11i ( url )
 ooOoOoo0O = url
 OoO000 = { 'Host' : 'series-top.com' , 'User-Agent' : ii , 'Referer' : ooOoOoo0O }
 O0O = re . compile ( 'data.orig.+?/show/(.+?) ' , re . DOTALL ) . findall ( OoOoOO00 )
 for url in O0O :
  url = url . replace ( '"' , '' ) . replace ( '\'' , '' )
  I1ii11iIi11i = url
  I1ii11iIi11i = I1ii11iIi11i . split ( '/' ) [ 0 ]
  I1ii11iIi11i = I1ii11iIi11i . replace ( '-' , ' ' ) . title ( )
  i1I11i ( '[B][COLOR white]%s[/COLOR][/B]' % I1ii11iIi11i , iIIii1IIi + 'show/%s' % url , 1 , O0OO00o0OO , o0O , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 44 - 44: oO0o0o0ooO0oO / oOooOoO0Oo0O % I11iIi1I * O0OOo + Oo0ooO0oo0oO
def i11iiII ( ) :
 try :
  Ii1I = getSet ( "core-player" )
  if ( Ii1I == 'DVDPLAYER' ) : Oo0o0 = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( Ii1I == 'MPLAYER' ) : Oo0o0 = xbmc . PLAYER_CORE_MPLAYER
  elif ( Ii1I == 'PAPLAYER' ) : Oo0o0 = xbmc . PLAYER_CORE_PAPLAYER
  else : Oo0o0 = xbmc . PLAYER_CORE_AUTO
 except : Oo0o0 = xbmc . PLAYER_CORE_AUTO
 return Oo0o0
 return True
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 49 - 49: O0OOo % o000o0o00o0Oo + I11iIi1I . o0OO0 % Oo0oO0ooo
def I1i1iii ( name , url ) :
 OoOoOO00 = I11i ( url )
 ooOoOoo0O = url
 OoO000 = { 'Host' : 'series-top.com' , 'User-Agent' : ii , 'Referer' : ooOoOoo0O }
 O0O = re . compile ( 'http://(.+?) ' , re . DOTALL ) . findall ( OoOoOO00 )
 for url in O0O :
  url = url . replace ( '"' , '' ) . replace ( '\'' , '' )
  i1iiI11I = url
  i1iiI11I = i1iiI11I . split ( '/' ) [ 0 ] . replace ( 'www.' , '' ) . capitalize ( )
  url = 'http://' + url
  if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   Ii11iI1i ( '[B][COLOR white]%s[/COLOR][/B]' % i1iiI11I , url , 100 , O0OO00o0OO , o0O , name )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 29 - 29: OOooOOo
def iI ( ) :
 I1i1I1II = [ ]
 i1 = sys . argv [ 2 ]
 if len ( i1 ) >= 2 :
  IiIiiI = sys . argv [ 2 ]
  I1I = IiIiiI . replace ( '?' , '' )
  if ( IiIiiI [ len ( IiIiiI ) - 1 ] == '/' ) :
   IiIiiI = IiIiiI [ 0 : len ( IiIiiI ) - 2 ]
  oOO00oOO = I1I . split ( '&' )
  I1i1I1II = { }
  for OoOo in range ( len ( oOO00oOO ) ) :
   iIo00O = { }
   iIo00O = oOO00oOO [ OoOo ] . split ( '=' )
   if ( len ( iIo00O ) ) == 2 :
    I1i1I1II [ iIo00O [ 0 ] ] = iIo00O [ 1 ]
    if 69 - 69: O0OOo % I1i1I - o00 + I1i1I - oOooOoO0Oo0O % OOooOOo
 return I1i1I1II
 if 31 - 31: IiiIII111iI - II1Iiii1111i . I1i1I % o00ooo0 - oOooOoO0Oo0O
IiIiiI = iI ( )
Oo = None
I1ii11iIi11i = None
O0OO00o0OO = None
iii11 = None
O0oo0OO0oOOOo = None
i1i1i11IIi = None
if 33 - 33: o00 + II1Iiii1111i * I1i1iI1i - Oo0ooO0oo0oO / O0OOo % o000o0o00o0Oo
if 21 - 21: I1i1iI1i * oO0o % O0OOo * I11iIi1I
try :
 Oo = urllib . unquote_plus ( IiIiiI [ "url" ] )
except :
 pass
try :
 I1ii11iIi11i = urllib . unquote_plus ( IiIiiI [ "name" ] )
except :
 pass
try :
 O0OO00o0OO = urllib . unquote_plus ( IiIiiI [ "iconimage" ] )
except :
 pass
try :
 iii11 = int ( IiIiiI [ "mode" ] )
except :
 pass
try :
 O0oo0OO0oOOOo = urllib . unquote_plus ( IiIiiI [ "fanart" ] )
except :
 pass
try :
 i1i1i11IIi = urllib . unquote_plus ( IiIiiI [ "description" ] )
except :
 pass
 if 16 - 16: oOooOoO0Oo0O - I1i1I * oO0o + ii11
 if 50 - 50: IiiIII111iI - OoOoo0 * Oo0oO0ooo / I1i1I + o00
print str ( iI11I1II1I1I ) + ': ' + str ( oooo )
print "Mode: " + str ( iii11 )
print "URL: " + str ( Oo )
print "Name: " + str ( I1ii11iIi11i )
print "IconImage: " + str ( O0OO00o0OO )
if 88 - 88: o000o0o00o0Oo / I1i1I + ii11 - IiiIII111iI / OoOoo0 - o00ooo0
if 15 - 15: Oo0oO0ooo + o00ooo0 - OOooOOo / II1Iiii1111i
if iii11 == None : iI1 ( )
elif iii11 == 1 : I1i1iii ( I1ii11iIi11i , Oo )
elif iii11 == 2 : o0oOoO00o ( )
elif iii11 == 3 : Oo00OOOOO ( Oo )
elif iii11 == 4 : II ( Oo )
elif iii11 == 5 : I1Ii ( )
elif iii11 == 100 : iIiiI1 ( I1ii11iIi11i , Oo , O0OO00o0OO , i1i1i11IIi )
if 58 - 58: i11i % OOo000
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
