# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy
import urlresolver
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.tvtimes/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'tvtimes'
VERSION = '0.0.4'
BASEURL = 'http://tv-release.net'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR white]Movies XviD[/COLOR][/B]','http://tv-release.net/?cat=Movies-XviD',5,ICON,FANART,'')
    Menu('[B][COLOR white]Movies 720[/COLOR][/B]','http://tv-release.net/?cat=Movies-720p',5,ICON,FANART,'')
    Menu('[B][COLOR white]Movies 480[/COLOR][/B]','http://tv-release.net/?cat=Movies-480p',5,ICON,FANART,'')
    Menu('[B][COLOR blue]TV 720[/COLOR][/B]','http://tv-release.net/?cat=TV-720p',5,ICON,FANART,'')
    Menu('[B][COLOR blue]TV 480[/COLOR][/B]','http://tv-release.net/?cat=TV-480p',5,ICON,FANART,'')
    Menu('[B][COLOR blue]TV Mp4[/COLOR][/B]','http://tv-release.net/?cat=TV-Mp4',5,ICON,FANART,'')
    Menu('[B][COLOR blue]TV XviD[/COLOR][/B]','http://tv-release.net/?cat=TV-XviD',5,ICON,FANART,'')
    Menu('[B][COLOR red]Search[/COLOR][/B]','url',6,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<td class='w64'.+?<a href='(.+?)'>(.+?)</a></td><td class='w18'>(.+?) .+?</td>",re.DOTALL).findall(OPEN)
    for url,name,date in Regex:
                name = name.replace(' 480p HDTV x264','').replace(' 480p x264-mSD','').replace(' 720p HDTV x264','').replace('-W4F','').replace('-DHD','').replace(' 720p WEB','').replace(' 480p WEBRip x264','').replace(' 480p WEB-DL x264','')
                name2= name+' '+'[B][COLOR blue]%s[/COLOR]'%date
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name2,url,10,ICON,FANART,'')
    np = re.compile('<span class=\'(.+?)\'>.+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for name,url in np:
            if 'zmg_pn_current' in name:
                    Menu('[B][COLOR blue]Next Page >>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    xbmc.executebuiltin('Container.SetViewMode(50)')
		
	
def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile("href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in Regex:
        name2 = url.split('//')[1].replace('www.','')
        name2 = name2.split('/')[0].split('.')[0].title()
        if urlresolver.HostedMediaFile(url).valid_url():
            if '.rar' not in url:
                if 'Filefactory' in name2:
                    name2=name2.replace('Filefactory','[B][COLOR red]FileFactory[/COLOR][/B]')
                    Play(name2,url,100,ART + 'filefactory.jpg',FANART,name)
                if 'Rapidgator' in name2:
                    name2=name2.replace('Rapidgator','[B][COLOR orange]Rapidgator[/COLOR][/B]')
                    Play(name2,url,100,ART + 'rapid.jpg',FANART,name)
                if 'Ul' in name2:
                    name2=name2.replace('Ul','[B][COLOR blue]Uploaded[/COLOR][/B]')
                    Play(name2,url,100,ART + 'uploaded.jpg',FANART,name)
                if 'Uploading' in name2:
                    name2=name2.replace('Uploading','[B][COLOR white]UploadingSite[/COLOR][/B]')
                    Play(name2,url,100,ART + 'upsite.jpg',FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','%20')
                url = BASEURL + '/?s=' + search + '&cat='
                Get_content(url)
    

########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    name = description
    iconimage=ICON
    OPEN = Open_Url(url)
    xbmc.executebuiltin("XBMC.Notification([COLOR blue]Attepting to[/COLOR],[COLOR red]Resolve Link[/COLOR] ,2000)") 
    play=urlresolver.HostedMediaFile(url).resolve()
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
