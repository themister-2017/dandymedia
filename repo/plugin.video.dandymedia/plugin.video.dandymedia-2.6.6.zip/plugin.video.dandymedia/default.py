# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.dandymedia/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'dandymedia'
VERSION = '2.6.6'
BASEURL = 'http://www.perfecthdmovies.pw/'
BASEURL2 = 'http://loadmovie.biz/'
BASEURL3 = 'http://cooltvseries.com/'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR white]1080p Movies[/COLOR][/B]',BASEURL + 'category/hollywood/hollywood-blu-ray-1080p/',5,ART + '1080mov.jpg',FANART,'')
    Menu('[B][COLOR white]720p Movies[/COLOR][/B]',BASEURL + 'category/hollywood/hollywood-blu-ray-720p/',5,ART + '720mov.jpg',FANART,'')
    Menu('[B][COLOR white]1080p Web-DL[/COLOR][/B]',BASEURL + 'category/hollywood/hollywood-web-dl-1080p/',5,ART + '1080web.jpg',FANART,'')
    Menu('[B][COLOR white]720p Web_DL[/COLOR][/B]',BASEURL + 'category/hollywood/hollywood-web-dl-720p/',5,ART + '720web.jpg',FANART,'')
    Menu('[B][COLOR white]IMDB Playlist[/COLOR][/B]','https://raw.githubusercontent.com/dandy0850/iStream/master/dandymedia_2/hevc.xml',7,ART + 'hevc.jpg',FANART,'')
    Menu('[B][COLOR white]More Debrid Movies[/COLOR][/B]','',50,ART + 'debrid2.jpg',FANART,'')
    Menu('[B][COLOR white]HD TV Shows[/COLOR][/B]','',70,ART + 'hdtvshows.jpg',FANART,'')
    Menu('[B][COLOR white]Popular TV SHOWS[/COLOR][/B]','http://flixyseries.com/series/',20,ART + 'toptv.jpg',FANART,'')
    Menu('[B][COLOR white]Latest Debrid TV[/COLOR][/B]','http://allrls.net/category/tv-shows/',25,ART + 'debtv.jpg',FANART,'')
    Menu('[B][COLOR white]HD Concerts[/COLOR][/B]','https://raw.githubusercontent.com/dandy0850/iStream/master/dandymedia_2/hdconcerts.xml',7,ART + 'live.jpg',FANART,'')
    Menu('[B][COLOR white]Anime[/COLOR][/B]','http://flixyseries.com/animes/',20,ART + 'anime.jpg',FANART,'')
    Menu('[B][COLOR white]Top Documentary[/COLOR][/B]','http://topdocumentaryfilms.com/watch-online/',60,ART + 'docu.jpg',FANART,'')
    Menu('[B][COLOR white]UK Soaps[/COLOR][/B]','',30,ART + 'uksoaps.jpg',FANART,'')
    Menu('[B][COLOR white]Childrens[/COLOR][/B]','https://raw.githubusercontent.com/dandy0850/iStream/master/test/bobbychans.txt',8,ART + 'kidstv.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')
#########################
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="item">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.split('1080p')[0].split('720p')[0].split('BRRip')[0].split('BDRip')[0].split('HDRip')[0]
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile("<link rel='next' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
            Menu('[B][COLOR lime]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('alt="dl"(.+?)<div id="cap3">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)"><b><.+?>(.+?)</span></b></a>',re.DOTALL).findall(str(Regex))
    for url,name2 in Regex2:
                if urlresolver.HostedMediaFile(url):
                    name2 = name2.replace('USERSCLOUD','USERSCLOUD [COLOR red](Debrid Req)[/COLOR]')
                    Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
                if 'MULTIUP' in name2:
                    url=url.replace('https://www.multiup.org/download/','http://www.multiup.org/en/mirror/').replace('http://www.multiup.org/download/','http://www.multiup.org/en/mirror/')
                    Multiurl = Open_Url(url)
                    links = re.compile('nameHost="(.+?)".+?validity=(.+?)dateLastChecked=.+?href="(.+?)"',re.DOTALL).findall(Multiurl)
                    for name2, validity, url in links:
                        name2 = name2.replace('clicknupload.link','Clicknupload [COLOR red](Debrid Req)[/COLOR]').replace('userscloud.com','userscloud.com [COLOR red](Debrid Req)[/COLOR]')
                        if 'invalid' not in validity:
                            if urlresolver.HostedMediaFile(url):
                                if 'filecloud.io' not in name2:
                                    Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_multi_links(name,url,iconimage,description):
        name = description
        OPEN = Open_Url(url)
        Regex = re.compile('nameHost="(.+?)".+?validity=(.+?)dateLastChecked=.+?href="(.+?)"',re.DOTALL).findall(OPEN)
        for name2, validity, url in Regex:
                if 'invalid' not in validity:
                        if urlresolver.HostedMediaFile(url):
                            if 'filecloud.io' not in name2:
                                Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
                                
#########################

#########################
def Debtv_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h2 class="entry-title"><a href="(.+?)".+?rel="bookmark">(.+?)</a></h2>',re.DOTALL).findall(OPEN)
    for url,name in Regex:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,26,ART + 'debtv.jpg',FANART,'')
    np = re.compile('<div style="float:right;"><a href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
            Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]',url,25,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Debtv_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<a href=(.+?)\ target=_blank>(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
            if urlresolver.HostedMediaFile(url):
                    Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')
#########################

def nitro_menu():
    Menu('[B][COLOR white]All Movies[/COLOR][/B]','http://loadmovie.biz/',51,ICON,FANART,'')
    OPEN = Open_Url('http://loadmovie.biz')
    Regex = re.compile('<ul id="menu-channels"(.+?)</ul></div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,51,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def nitro_content(url):
    referer = url
    headers = {'Host': 'loadmovie.biz', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="post-title text-left">.+?<a href="(.+?)">(.+?)</a>.+?<img src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
            name = name.replace('2016','(2016)').replace('2015','(2015)').replace('2014','(2014)').replace('2013','(2013)').replace('2012','(2012)').replace('2011','(2011)').replace('&#8217;','\'').replace('&#8212;',' - ')
            if 'Your support | Ask movie' not in name:
                if 'Most Popular Movies In (2016)' not in name:             
                    Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,52,icon,FANART,'')
    np = re.compile('rel="next" href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in np:
            if '&raquo;' in name:
                    Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]',url,52,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def nitro_links(name,url,iconimage):
    OPEN = Open_Url(url)
    Regex = re.compile('<strong>Quality.+?</strong>(.+?),.+?<a href=.+?href=.+?href=.+?<a href="(.+?)"',re.DOTALL).findall(OPEN)
    for host,url in Regex:
                Play('[B][COLOR white]Link Quality %s[/COLOR][/B]' %host,BASEURL2+url,100,iconimage,FANART,name)
    Regex1 = re.compile('Quality 1:.+?>(.+?),.+?<a href=.+?href=.+?href=.+?<a href="(.+?)"',re.DOTALL).findall(OPEN)
    for host,url in Regex1:
            host = host.replace('<span class="bbcode-text">','').replace('</span>','')
            Play('[B][COLOR white]Link Quality %s[/COLOR][/B]' %host,BASEURL2+url,100,iconimage,FANART,name)
    Regex2 = re.compile('Quality 2:.+?>(.+?),.+?<a href=.+?href=.+?href=.+?<a href="(.+?)"',re.DOTALL).findall(OPEN)
    for host,url in Regex2:
            host = host.replace('<span class="bbcode-text">','').replace('</span>','')
            Play('[B][COLOR white]Link Quality %s[/COLOR][/B]' %host,BASEURL2+url,100,iconimage,FANART,name)
    Regex3 = re.compile('Quality 3:.+?>(.+?),.+?<a href=.+?href=.+?href=.+?<a href="(.+?)"',re.DOTALL).findall(OPEN)
    for host,url in Regex3:
                Play('[B][COLOR white]Link Quality %s[/COLOR][/B]' %host,BASEURL2+url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

#########################
def Get_shows(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="column-3">.+?<a href="(.+?)">.+?src="(.+?)" >.+?<h2>(.+?)</h2>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            url = url.replace('../../../../','http://flixyseries.com/')
            icon = icon.replace('../../../../','http://flixyseries.com/')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,21,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

def Get_seasons(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="seasons">(.+?)</div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('../../../../','http://flixyseries.com/')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,22,iconimage,iconimage,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="column-6">.+?<a href="(.+?)" class="serie_box_a">.+?class="serie_ep_num">(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,name in Regex:
            url = url.replace('../../../../','http://flixyseries.com/')
            Play('[B][COLOR white]Episode %s[/COLOR][/B]' %name,url,200,iconimage,iconimage,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')	
#########################
def Dir_playlist(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<name>(.+?)</name>.+?<thumbnail>(.+?)</thumbnail>.+?<externallink>(.+?)</externallink>.+?<fanart>(.+?)</fanart>',re.DOTALL).findall(OPEN)
    for name,icon,url,fanart in Regex:
        if 'txt' in url:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,8,icon,fanart,'')
        else:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,7,icon,fanart,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_playlist(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<title>(.+?)</title>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>',re.DOTALL).findall(OPEN)
    for name,url,icon,fanart in Regex:
        if 'xml' in url:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,7,icon,fanart,'')
        else:
            Play('[B][COLOR white]%s[/COLOR][/B]' %name,url,150,icon,fanart,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
#########################

def UK_soaps():
    Menu('[B][COLOR red]Coronation Street[/COLOR][/B]','http://watchseries-online.nl/category/coronation-street',31,'http://thetvdb.com/banners/_cache/posters/71565-2.jpg','http://thetvdb.com/banners/fanart/original/71565-2.jpg','')
    Menu('[B][COLOR red]Eastenders[/COLOR][/B]','http://watchseries-online.nl/category/eastenders',31,'http://thetvdb.com/banners/_cache/posters/71753-2.jpg','http://thetvdb.com/banners/fanart/original/71753-7.jpg','')
    Menu('[B][COLOR red]Emmerdale[/COLOR][/B]','http://watchseries-online.nl/category/emmerdale',31,'http://thetvdb.com/banners/_cache/posters/77715-2.jpg','http://thetvdb.com/banners/fanart/original/77715-3.jpg','')
    Menu('[B][COLOR red]Casualty[/COLOR][/B]','http://watchseries-online.nl/category/casualty',31,'http://thetvdb.com/banners/_cache/posters/71756-4.jpg','http://thetvdb.com/banners/fanart/original/71756-2.jpg','')
    Menu('[B][COLOR red]Holby City[/COLOR][/B]','http://watchseries-online.nl/category/holby-city',31,'http://thetvdb.com/banners/_cache/posters/77235-1.jpg','http://thetvdb.com/banners/fanart/original/77235-3.jpg','')
    Menu('[B][COLOR red]Hollyoaks[/COLOR][/B]','http://watchseries-online.nl/category/hollyoaks',31,'http://thetvdb.com/banners/_cache/posters/78006-1.jpg','http://thetvdb.com/banners/fanart/original/78006-1.jpg','')
    Menu('[B][COLOR red]Doctors[/COLOR][/B]','http://watchseries-online.nl/category/doctors',31,'http://thetvdb.com/banners/_cache/posters/83729-2.jpg','http://thetvdb.com/banners/fanart/original/83729-1.jpg','')
    Menu('[B][COLOR red]Home & Away[/COLOR][/B]','http://watchseries-online.nl/category/home-and-away',31,'http://thetvdb.com/banners/_cache/posters/71890-2.jpg','http://thetvdb.com/banners/fanart/original/71890-1.jpg','')
    Menu('[B][COLOR red]Neighbours[/COLOR][/B]','http://watchseries-online.nl/category/neighbours',31,'http://thetvdb.com/banners/_cache/posters/76719-2.jpg','http://thetvdb.com/banners/fanart/original/76719-2.jpg','')

def list_ep(url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'watchseries-online.nl', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile("<li class='listEpisode'>.+?href='(.+?)'.+?</span>(.+?)</a>",re.DOTALL).findall(OPEN)
    for url,name in Regex:
            name = name.replace('&#8211;','-')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,32,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')    

def list_li(name,url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'series-top.com', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('<img class="host-icon".+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
            if urlresolver.HostedMediaFile(url).valid_url():
                Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')    
#########################
def hdtv_menu():
    Menu('[B][COLOR blue]Popular Shows[/COLOR][/B]','http://cooltvseries.com/popular-tv-shows/',71,ART + 'hdtvshows.jpg',FANART,'')
    Menu('[B][COLOR blue]Latest Episodes[/COLOR][/B]','http://cooltvseries.com/moreupdates/',74,ART + 'hdtvshows.jpg',FANART,'')
    Menu('[B][COLOR blue]Alphabetically[/COLOR][/B]','',72,ART + 'hdtvshows.jpg',FANART,'')
    Menu('[B][COLOR red]Search HDTV[/COLOR][/B]','url',77,ART + 'hdtvshows.jpg',FANART,'')
    OPEN = Open_Url('http://cooltvseries.com/popular-tv-shows/')
    Regex = re.compile('<h3 class="sidebar-title">Browse By Category</h3>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('https','http')
            if 'Documentary' not in name:
                if 'Music' not in name:
                    if 'Sport' not in name:
                        if 'War' not in name:
                            if 'Western' not in name:
                                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,71,ART + 'hdtvshows.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def hdtv_genres():
    OPEN = Open_Url('http://cooltvseries.com/popular-tv-shows/')
    Regex = re.compile('<h3 class="sidebar-title">Browse By Category</h3>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('https','http')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,71,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def hdtv_alpha():
    OPEN = Open_Url('http://cooltvseries.com/popular-tv-shows/')
    Regex = re.compile('<h3 class="sidebar-title">Browse By Alphabetically</h3>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('https','http')
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,71,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def hdtv_Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="box">.+?<img src="(.+?)".+?<a href="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            url = url.replace('https','http')
            icon = icon.replace('//','http://')
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,75,icon,FANART,'')
    np = re.compile('<li class="next"><a href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
            url = url.replace('https','http')
            Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]',url,71,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')
    
def hdtv_latest_ep(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="box">.+?<img src="(.+?)".+?<a href="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            url = url.replace('https','http')
            icon = icon.replace('//','http://')
            Play('[B][COLOR blue]%s[/COLOR][/B]' %name,url,80,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def hdtv_Get_seasons(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="dwn-box">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('https','http')
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,76,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def hdtv_Get_episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="dwn-box">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)<span',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('https','http')
            Play('[B][COLOR blue]%s[/COLOR][/B]' %name,url,80,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def hdtv_Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL3 + 'search.php?search=' + search
                hdtv_search_res(url)

def hdtv_search_res(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="box">.+?<img src="(.+?)".+?<a href="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            url = url.replace('https','http')
            icon = icon.replace('//','http://')
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,76,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')  

#########################
def doc_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="sitemap-wraper clear">.+?</h2>(.+?)</div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)" title="(.+?)"><img.+?src="(.+?)".+?</a>',re.DOTALL).findall(str(Regex))
    for url,name,icon in Regex2:
            name=name.replace('&#039;','\'')
            icon=icon.replace('-150x198','')
            Play('[B][COLOR blue]%s[/COLOR][/B]' %name,url,150,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
#########################
def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def resolve(name,url,iconimage,description):
    name=description
    xbmc.executebuiltin("XBMC.Notification([COLOR red]DandyMedia[/COLOR],[COLOR cornflowerblue]Resolving Link[/COLOR] ,3000)") 
    if 'loadmovie.biz' in url:
            headers = {'User-Agent': User_Agent}
            r = requests.get(url,headers=headers,allow_redirects=False)
            url = r.headers['location'] 
            play=urlresolver.HostedMediaFile(url).resolve()

    else:   
            play=urlresolver.HostedMediaFile(url).resolve()
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)  
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def alt_resolve(name,url,iconimage,description):
    xbmc.executebuiltin("XBMC.Notification([COLOR red]DandyMedia[/COLOR],[COLOR cornflowerblue]Resolving Link[/COLOR] ,2000)")
    if 'dailymotion' in url:
            xbmc.log(url)
            OPEN = Open_Url(url)
            try:
                    url = re.compile('"video\\\/mp4","url":"(.*?)"',re.DOTALL).findall(OPEN)[-1]
            except:
                    url = re.compile('"video\\\/mp4","url":"(.*?)"',re.DOTALL).findall(OPEN)[0]
            url = url.replace('\/','/')
            play=urlresolver.resolve(url)
    if 'topdocumentaryfilms' in url:
            OPEN = Open_Url(url)
            url = re.compile('<meta itemprop="embedUrl" content="(.+?)"',re.DOTALL).findall(OPEN)[0]
            if 'vimeo' in url:
                url = url.replace('https://player.vimeo.com/video/','plugin://plugin.video.vimeo/play/?video_id=')
            else:
                url = url.replace('https://www.youtube.com/embed/','plugin://plugin.video.youtube/play/?video_id=')

    else:   
            play=urlresolver.resolve(url)
    
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)

    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)  
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def resolvetv(name,url,iconimage,description):
    OPEN = Open_Url(url)
    url = re.compile('<i class="fa fa-download ftl"></i>.+?<a href="(.+?)"',re.DOTALL).findall(OPEN)[0]
    xbmc.executebuiltin("XBMC.Notification([COLOR red]DandyMedia[/COLOR],[COLOR cornflowerblue]Resolving Link[/COLOR] ,3000)")
    url = url.replace('https://flixyseries.com/goto/','https://openload.co/f/')    
    play=urlresolver.resolve(url)
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def hdtv_resolve(name,url,iconimage,description):
    OPEN = Open_Url(url)
    dialog = xbmcgui.Dialog()
    servers = dialog.yesno('[B][COLOR red]Quality[/COLOR][/B]', '[CR]                             [B][COLOR blue]Please Select Your Resolution[/COLOR][/B]', yeslabel='480 SD', nolabel='720 HD')
    if servers:
            url = re.compile('<h4>480p.+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
            url = url.replace('https','http')
    else:
            url = re.compile('<h4>720p.+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
            url = url.replace('https','http')

    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################

if mode == None: Main_menu()
elif mode == 5 : Get_content(url)
elif mode == 10 : Get_links(name,url)
elif mode == 11 : Get_multi_links(name,url,iconimage,description)
elif mode == 8 : Dir_playlist(url)
elif mode == 7 : Get_playlist(url)
elif mode == 20 : Get_shows(url)
elif mode == 22 : Get_episodes(url)
elif mode == 21 : Get_seasons(url)
elif mode == 25 : Debtv_content(url)
elif mode == 26 : Debtv_links(name,url)
elif mode == 30 : UK_soaps()
elif mode == 31 : list_ep(url)
elif mode == 32 : list_li(name,url)
elif mode == 50 : nitro_menu()
elif mode == 51 : nitro_content(url)
elif mode == 52 : nitro_links(name,url,iconimage)
elif mode == 60 : doc_content(url)
elif mode == 70 : hdtv_menu()
elif mode == 71 : hdtv_Get_content(url)
elif mode == 72 : hdtv_alpha()
elif mode == 73 : hdtv_genres()
elif mode == 74 : hdtv_latest_ep(url)
elif mode == 75 : hdtv_Get_seasons(url)
elif mode == 76 : hdtv_Get_episodes(url)
elif mode == 77 : hdtv_Search()
elif mode == 80 : hdtv_resolve(name,url,iconimage,description)
elif mode == 100 : resolve(name,url,iconimage,description)
elif mode == 150 : alt_resolve(name,url,iconimage,description)
elif mode == 200 : resolvetv(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
