# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, base64
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.movieecho/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'movieecho'
VERSION = '0.0.1'
BASEURL = 'http://www.movieecho.com'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR white]Movies - Date Added[/COLOR][/B]',BASEURL+'/?sort=featured',5,ART + 'mda.jpg',FANART,'')
    Menu('[B][COLOR white]Movies - Popular[/COLOR][/B]',BASEURL+'/?sort=views',5,ART + 'mpop.jpg',FANART,'')
    Menu('[B][COLOR white]Movies - Rated[/COLOR][/B]',BASEURL+'/?sort=ratings',5,ART + 'mrate.jpg',FANART,'')
    Menu('[B][COLOR white]Movies - Favourites[/COLOR][/B]',BASEURL+'/?sort=favorites',5,ART + 'mfav.jpg',FANART,'')
    Menu('[B][COLOR white]Movies - Release Date[/COLOR][/B]',BASEURL+'/?sort=release',5,ART + 'mrel.jpg',FANART,'')
    Menu('[B][COLOR white]Movie -  Genres[/COLOR][/B]','',3,ART + 'mgen.jpg',FANART,'')
    Menu('[B][COLOR red]Search Movies[/COLOR][/B]','url',6,ART + 'msearch.jpg',FANART,'')
    Menu('[B][COLOR white]TV Shows - Date Added[/COLOR][/B]',BASEURL+'/?tv=&sort=date',7,ART + 'tvdate.jpg',FANART,'')
    Menu('[B][COLOR white]TV Shows - Popular[/COLOR][/B]',BASEURL+'/?tv=&sort=views',7,ART + 'tvpop.jpg',FANART,'')
    Menu('[B][COLOR white]TV Shows - Rated[/COLOR][/B]',BASEURL+'/?tv=&sort=ratings',7,ART + 'tvrated.jpg',FANART,'')
    Menu('[B][COLOR white]TV Shows - Favorites[/COLOR][/B]',BASEURL+'/?tv=&sort=favorites',7,ART + 'tvfav.jpg',FANART,'')
    Menu('[B][COLOR white]TV Shows - Release Date[/COLOR][/B]',BASEURL+'/?tv=&sort=release',7,ART + 'tvrel.jpg',FANART,'')
    Menu('[B][COLOR white]TV Shows -  Genres[/COLOR][/B]','',12,ART + 'tvgenre.jpg',FANART,'')
    Menu('[B][COLOR red]Search TV Shows[/COLOR][/B]','url',11,ART + 'tvsearch.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Get_Genres():
    OPEN = Open_Url('http://www.movieecho.com/')
    Regex = re.compile('data-toggle="dropdown">Genre<span(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'mgen.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_TVGenres():
    OPEN = Open_Url('http://www.movieecho.com/?tv')
    Regex = re.compile('data-toggle="dropdown">Genre<span(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,7,ART + 'tvgenre.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):
    referer = url
    headers = {'Host': 'www.movieecho.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="item">.+?<a href="(.+?)" title="(.+?)">.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
            name = name.replace('Watch ','').replace('Online Free','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,10,icon,FANART,'')
    np = re.compile('<nav class="pagination">(.+?)<div style="clear: both">',re.DOTALL).findall(OPEN)
    np2 = re.compile('<a class="(.+?)".+?href="(.+?)">',re.DOTALL).findall(str(np))
    for name,url in np2:
            if 'current first num' in name:
                    Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]',BASEURL+url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_shows(url):
    referer = url
    headers = {'Host': 'www.movieecho.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="item">.+?<a href="(.+?)".+?src="(.+?)".+?<h2 class="movie-title">(.+?)</h2>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,8,icon,FANART,'')
    np = re.compile('<nav class="pagination">(.+?)<div style="clear: both">',re.DOTALL).findall(OPEN)
    np2 = re.compile('<a class="(.+?)".+?href="(.+?)">',re.DOTALL).findall(str(np))
    for name,url in np2:
            if 'current first num' in name:
                    Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]',BASEURL+url,7,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_seasons(url):
    referer = url
    headers = {'Host': 'www.movieecho.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('class="season-toggle" href="(.+?)">(.+?)<span',re.DOTALL).findall(OPEN)
    for url,name in Regex:
            name = name.replace('&#9658; ','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,9,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_episodes(url):
    referer = url
    headers = {'Host': 'www.movieecho.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="tv_episode_item"> <a href="(.+?)">(.+?)<span class="tv_episode_name">(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,namex,namey in Regex:
            name = namex+namey
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,10,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_links(name,url,iconimage):
    OPEN = Open_Url(url)
    Regex = re.compile('<span class="version_host">(.+?)</span>.+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for name2, url in Regex:
            if 'Sponsor Host' not in name2:
                    if 'Promo Host' not in name2:
                            if 'estream.to' not in name2:
                                    if 'nosvideo.com' not in name2:
                                            if 'thevideobee.to' not in name2:
                                                        if 'nowvideo.sx' not in name2:
                                                            Play('[B][COLOR white]%s[/COLOR][/B]' %name2,BASEURL+url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')



def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?search_keywords=' + search
                Get_content(url)
    
def SearchTV():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?tv=&search_keywords=' + search
                Get_shows(url)
	
########################################


def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def resolve(name,url,iconimage,description):
    name = description
    headers = {'User-Agent': User_Agent}
    r = requests.get(url,headers=headers,allow_redirects=False)
    url = r.headers['location'] 
    xbmc.executebuiltin("XBMC.Notification([COLOR orange]Attempting To[/COLOR],[COLOR green]Resolve Link[/COLOR] ,3000)")
    play=urlresolver.resolve(url)
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
		


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres()
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 7 : Get_shows(url)
elif mode == 8 : Get_seasons(url)
elif mode == 9 : Get_episodes(url)
elif mode == 10 : Get_links(name,url,iconimage)
elif mode == 11 : SearchTV()
elif mode == 12 : Get_TVGenres()
elif mode == 100 : resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
