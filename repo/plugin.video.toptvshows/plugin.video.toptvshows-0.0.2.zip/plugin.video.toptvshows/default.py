# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, base64
import urlresolver

User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.toptvshows/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'toptvshows'
VERSION = '0.0.2'
BASEURL = 'http://flixyseries.com'
ART = ADDON_PATH + "resources/icons/"

def Get_shows():
    OPEN = Open_Url('http://flixyseries.com/series/')
    Regex = re.compile('<div class="column-3">.+?<a href="(.+?)">.+?src="(.+?)" >.+?<h2>(.+?)</h2>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            url = url.replace('../../../../','http://flixyseries.com/')
            icon = icon.replace('../../../../','http://flixyseries.com/')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

def Get_seasons(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="seasons">(.+?)</div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('../../../../','http://flixyseries.com/')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="column-6">.+?<a href="(.+?)" class="serie_box_a">.+?class="serie_ep_num">(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,name in Regex:
            url = url.replace('../../../../','http://flixyseries.com/')
            Play('[B][COLOR white]Episode %s[/COLOR][/B]' %name,url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')


	
########################################


def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def resolve(name,url,iconimage,description):
    OPEN = Open_Url(url)
    url = re.compile('<i class="fa fa-download ftl"></i>.+?<a href="(.+?)"',re.DOTALL).findall(OPEN)[0]
    xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Attempting[/COLOR],[COLOR cornflowerblue]To Resolve Link[/COLOR] ,5000)")
    url = url.replace('https://flixyseries.com/goto/','https://openload.co/f/')    
    play=urlresolver.resolve(url)
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
		


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Get_shows()
elif mode == 1 : Get_seasons(url)
elif mode == 2 : Get_episodes(url)
elif mode == 100 : resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
