# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.hevcvideoclub/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'hevcvideoclub'
VERSION = '1.2.1'
BASEURL = 'http://www.300mbmoviesdl.com/'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR white]Recently Added[/COLOR][/B]',BASEURL,5,ART + 'recent.jpg',FANART,'')
    Menu('[B][COLOR white]720p Movies[/COLOR][/B]',BASEURL + 'category/english-720p-bluray-movies/',5,ART + '720p.jpg',FANART,'')
    Menu('[B][COLOR white]1080p Movies[/COLOR][/B]',BASEURL + 'category/english-1080p-bluray-movies/',5,ART + '1080p.jpg',FANART,'')
    Menu('[B][COLOR white]720p WEB-DL[/COLOR][/B]',BASEURL + 'category/english-720p-web-dl/',5,ART + '720p.jpg',FANART,'')
    Menu('[B][COLOR white]1080p WEB-DL[/COLOR][/B]',BASEURL + 'category/english-1080p-web-dl/',5,ART + '1080p.jpg',FANART,'')
    Menu('[B][COLOR white]IMDB[/COLOR][/B]','http://300mbmovies4u.net/category/hollywood-movie/imdb-top-250-movie/',7,ART + 'imdb.jpg',FANART,'')
    Menu('[B][COLOR white]More HEVC[/COLOR][/B]','http://300mbmovies4u.net/category/hevc-movie/',7,ICON,FANART,'')
    Menu('[B][COLOR white]3D Movies[/COLOR][/B]','http://300mbmovies4u.net/category/hollywood-movie/english-3d-movie/',7,ART + '3Dmov.jpg',FANART,'')
    Menu('[B][COLOR white]Latest TV Episodes[/COLOR][/B]',BASEURL + 'category/tv-shows/',5,ICON,FANART,'')
    Menu('[B][COLOR red]Search Movies[/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

	
def Get_content(url):
    referer = url
    headers = {'Host': 'www.300mbmoviesdl.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="cover">.+?<a href="(.+?)" title="(.+?)"><img src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
            name = name.replace('HEVC','-').replace('&#8217;','').replace('720p',' - [COLOR blue](720p)[/COLOR]').replace('1080p',' - [COLOR blue](1080p)[/COLOR]')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile('<link rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_m4u(url):
    referer = url
    headers = {'Host': '300mbmovies4u.net', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('class="posts posts-3 grid ">(.+?)</ul><div',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<h2><a href="(.+?)" title="(.+?)".+?<img src="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,name,icon in Regex2:
            name = name.replace('HEVC','-').replace('&#8211;','').replace('&#8217;','').replace('720p',' - [COLOR blue](720p)[/COLOR]').replace('1080p',' - [COLOR blue](1080p)[/COLOR]')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile('<link rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,7,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')    
	
def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<strong>Download Links</strong>(.+?)<em>Related</em>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)"',re.DOTALL).findall(str(Regex))
    for url in Regex2:
            if 'amazon.com' in url:
                Play('[B][COLOR white]Direct Link[/COLOR][/B]',url,100,iconimage,FANART,name)
            if urlresolver.HostedMediaFile(url):
                    name2 = url.split('//')[1].replace('www.','')
                    name2 = name2.split('/')[0].capitalize()
                    name2 = name2.replace('Uploadx.org','Uploadx.org [COLOR red](Debrid Req)[/COLOR]').replace('Clicknupload.link','Clicknupload.link [COLOR red](Debrid Req)[/COLOR]').replace('Userscloud.com','Userscloud.com [COLOR red](Debrid Req)[/COLOR]')
                    if 'Filecloud.io' not in name2:
                        Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            if 'multiup.org' in url:
                    url=url.replace('https://www.multiup.org/download/','http://www.multiup.org/en/mirror/').replace('http://www.multiup.org/download/','http://www.multiup.org/en/mirror/')
                    OPEN = Open_Url(url)
                    Regex = re.compile('nameHost="(.+?)".+?validity=(.+?)dateLastChecked=.+?href="(.+?)"',re.DOTALL).findall(OPEN)
                    for name2, validity, url in Regex:
                        if 'invalid' not in validity:
                            if urlresolver.HostedMediaFile(url):
                                if 'filecloud.io' not in name2:
                                    name2 = name2.capitalize()
                                    Play('[B][COLOR white]%s [COLOR blue] (Multiup)[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    alt = re.compile('>Download Link</h1>(.+?)New Download Links',re.DOTALL).findall(OPEN)
    alt2 = re.compile('<a href="(.+?)"',re.DOTALL).findall(str(alt))
    for url in alt2:
            if urlresolver.HostedMediaFile(url):
                    name2 = url.split('//')[1].replace('www.','')
                    name2 = name2.split('/')[0].capitalize()
                    name2 = name2.replace('Uploadx.org','Uploadx.org [COLOR red](Debrid Req)[/COLOR]').replace('Clicknupload.link','Clicknupload.link [COLOR red](Debrid Req)[/COLOR]').replace('Userscloud.com','Userscloud.com [COLOR red](Debrid Req)[/COLOR]').replace('Clicknupload.me','Clicknupload.link [COLOR red](Debrid Req)[/COLOR]')
                    Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            if 'multiup.org' in url:
                    url=url.replace('https://www.multiup.org/download/','http://www.multiup.org/en/mirror/').replace('http://www.multiup.org/download/','http://www.multiup.org/en/mirror/')
                    OPEN = Open_Url(url)
                    Regex = re.compile('nameHost="(.+?)".+?validity=(.+?)dateLastChecked=.+?href="(.+?)"',re.DOTALL).findall(OPEN)
                    for name2, validity, url in Regex:
                        if 'invalid' not in validity:
                            if urlresolver.HostedMediaFile(url):
                                if 'filecloud.io' not in name2:
                                    name2 = name2.capitalize()
                                    Play('[B][COLOR white]%s [COLOR blue] (Multiup)[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)            
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '?s=' + search
                Get_content(url)
    

########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def resolve(name,url,iconimage,description):
    name = description 
    if 'amazon' in url:
        OPEN = Open_Url(url)
        xbmc.executebuiltin("XBMC.Notification([COLOR blue]     Direct Link[/COLOR],[COLOR red]If Fails Press Again[/COLOR] ,3000)")
        url = re.compile('secure_url\' content="(.+?)/alt/',re.DOTALL).findall(OPEN)[0]
        play=urlresolver.HostedMediaFile(url).resolve()

    else:
        xbmc.executebuiltin("XBMC.Notification([COLOR blue]Attempting to[/COLOR],[COLOR red]resolve Link[/COLOR] ,2000)")
        play=urlresolver.HostedMediaFile(url).resolve()

    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 5 : Get_content(url)
elif mode == 7 : Get_m4u(url)
elif mode == 6 : Search()
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
