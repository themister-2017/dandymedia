# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os
import urlresolver
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.bobbycart/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'bobbycart'
VERSION = '0.0.1'
ART = ADDON_PATH + "resources/icons/"


def Main_Menu():
    Menu('Aladdin','http://www.toonget.net/aladdin',2,'http://thetvdb.com/banners/_cache/posters/73981-5.jpg','http://thetvdb.com/banners/fanart/original/73981-5.jpg','')
    Menu('American Dad','http://www.kisspanda.net/american-dad/',1,'http://thetvdb.com/banners/_cache/posters/73141-7.jpg','http://thetvdb.com/banners/fanart/original/73141-3.jpg','')
    Menu('Angry Kid','http://www.toonget.net/angry-kid',2,'http://thetvdb.com/banners/_cache/posters/144661-1.jpg','http://thetvdb.com/banners/fanart/original/144661-4.jpg','')
    Menu('Animaniacs','http://www.toonget.net/animaniacs',2,'http://thetvdb.com/banners/_cache/posters/72879-4.jpg','http://thetvdb.com/banners/fanart/original/72879-6.jpg','')
    Menu('Arthur','http://www.toonget.net/arthur',2,'http://thetvdb.com/banners/_cache/posters/74678-3.jpg','http://thetvdb.com/banners/fanart/original/74678-3.jpg','')
    Menu('Baby Looney Tunes','http://www.toonget.net/baby-looney-tunes',2,'http://thetvdb.com/banners/_cache/posters/71301-4.jpg','http://thetvdb.com/banners/fanart/original/71301-2.jpg','')
    Menu('Bananaman','http://www.toonget.net/bananaman',2,'http://thetvdb.com/banners/_cache/posters/78672-2.jpg','http://thetvdb.com/banners/fanart/original/78672-2.jpg','')
    Menu('Bananas in Pyjamas 2011','http://www.toonget.net/bananas-in-pyjamas-2011',2,'http://thetvdb.com/banners/_cache/posters/250082-1.jpg','http://thetvdb.com/banners/fanart/original/250082-2.jpg','')
    Menu('Bob the Builder','http://www.toonget.net/bob-the-builder',2,'http://thetvdb.com/banners/_cache/posters/78685-2.jpg','http://thetvdb.com/banners/fanart/original/78685-2.jpg','')
    Menu('Bobs Burgers','http://www.toonget.net/bobs-burgers',2,'http://thetvdb.com/banners/_cache/posters/194031-3.jpg','http://thetvdb.com/banners/fanart/original/194031-5.jpg','')
    Menu('Charlie and Lola','http://www.toonget.net/charlie-and-lola',2,'http://thetvdb.com/banners/_cache/posters/75933-1.jpg','http://thetvdb.com/banners/fanart/original/75933-4.jpg','')
    Menu('Curious George','http://www.toonget.net/curious-george',2,'http://thetvdb.com/banners/_cache/posters/79429-5.jpg','http://thetvdb.com/banners/fanart/original/79429-3.jpg','')
    Menu('The Cleveland Show','http://www.toonget.net/the-cleveland-show',2,'http://thetvdb.com/banners/_cache/posters/93991-1.jpg','http://thetvdb.com/banners/fanart/original/93991-2.jpg','')
    Menu('Danger Mouse (2015)','http://www.toonget.net/danger-mouse-2015',2,'http://thetvdb.com/banners/_cache/posters/300969-3.jpg','http://thetvdb.com/banners/fanart/original/300969-2.jpg','')
    Menu('Dinosaurs','http://www.toonget.net/dinosaurs',2,'http://thetvdb.com/banners/_cache/posters/76461-6.jpg','http://thetvdb.com/banners/fanart/original/76461-6.jpg','')
    Menu('Dinosaur Train','http://www.toonget.net/dinosaur-train',2,'http://thetvdb.com/banners/_cache/posters/116291-2.jpg','http://thetvdb.com/banners/fanart/original/116291-4.jpg','')
    Menu('Dora the Explorer','http://www.toonget.net/dora-the-explorer',2,'http://thetvdb.com/banners/_cache/posters/74697-5.jpg','http://thetvdb.com/banners/fanart/original/74697-1.jpg','')
    Menu('Duck Tales','http://www.toonget.net/duck-tales',2,'http://thetvdb.com/banners/_cache/posters/75931-7.jpg','http://thetvdb.com/banners/fanart/original/75931-4.jpg','')
    Menu('Family Guy','http://www.kisspanda.net/family-guy/',1,'http://thetvdb.com/banners/_cache/posters/75978-17.jpg','http://thetvdb.com/banners/fanart/original/75978-23.jpg','')
    Menu('The Furchester Hotel','http://www.toonget.net/the-furchester-hotel',2,'http://thetvdb.com/banners/_cache/posters/286332-1.jpg','http://thetvdb.com/banners/fanart/original/286332-1.jpg','')
    Menu('Futurama','http://www.kisspanda.net/futurama/',1,'http://thetvdb.com/banners/_cache/posters/73871-7.jpg','http://thetvdb.com/banners/fanart/original/73871-33.jpg','')
    Menu('Garfield And Friends','http://www.toonget.net/garfield-and-friends',2,'http://thetvdb.com/banners/_cache/posters/77054-1.jpg','http://thetvdb.com/banners/fanart/original/77054-1.jpg','')
    Menu('He-Man And The Masters Of The Universe','http://www.toonget.net/he-man-and-the-masters-of-the-universe',2,'http://thetvdb.com/banners/_cache/posters/73014-3.jpg','http://thetvdb.com/banners/fanart/original/73014-1.jpg','')
    Menu('Kate and Mim-Mim','http://www.toonget.net/kate-and-mim-mim',2,'https://thetvdb.com/banners/_cache/posters/284464-1.jpg','https://thetvdb.com/banners/fanart/original/284464-1.jpg','')
    Menu('Kim Possible','http://www.toonget.net/kim-possible',2,'http://thetvdb.com/banners/_cache/posters/78259-1.jpg','http://thetvdb.com/banners/fanart/original/78259-2.jpg','')
    Menu('King of the Hill','http://www.toonget.net/king-of-the-hill',2,'http://thetvdb.com/banners/_cache/posters/73903-2.jpg','http://thetvdb.com/banners/fanart/original/73903-8.jpg','')
    Menu('Little Charley Bear','http://www.toonget.net/little-charley-bear',2,'http://thetvdb.com/banners/_cache/posters/220631-1.jpg','http://thetvdb.com/banners/fanart/original/220631-1.jpg','')
    Menu('Looney Tunes Golden Collection','http://www.toonget.net/looney-tunes-golden-collection',2,'https://upload.wikimedia.org/wikipedia/en/b/bd/Looney_Tunes_Golden_Collection_-_Volume_4.jpg','http://thetvdb.com/banners/fanart/original/72514-4.jpg','')    
    Menu('Looney Tunes Platinum Collection','http://www.toonget.net/looney-tunes-platinum-collection',2,'http://images2.static-bluray.com/movies/covers/101211_front.jpg','http://thetvdb.com/banners/fanart/original/72514-19.jpg','')    
    Menu('The Looney Tunes Show (2011)','http://www.toonget.net/the-looney-tunes-show-2011',2,'http://thetvdb.com/banners/_cache/posters/248368-3.jpg','http://thetvdb.com/banners/fanart/original/248368-2.jpg','')    
    Menu('Mickey Mouse Clubhouse','http://www.toonget.net/mickey-mouse-clubhouse',2,'http://thetvdb.com/banners/_cache/posters/79854-2.jpg','http://thetvdb.com/banners/fanart/original/79854-6.jpg','') 
    Menu('My Friends Tigger and Pooh','http://www.toonget.net/my-friends-tigger-and-pooh',2,'http://thetvdb.com/banners/_cache/posters/80850-1.jpg','http://thetvdb.com/banners/fanart/original/80850-1.jpg','')
    Menu('My Little Pony: Friendship Is Magic','http://www.toonget.net/my-little-pony-friendship-is-magic',2,'http://thetvdb.com/banners/_cache/posters/212171-5.jpg','http://thetvdb.com/banners/fanart/original/212171-14.jpg','')
    Menu('The Octonauts','http://www.toonget.net/the-octonauts',2,'https://thetvdb.com/banners/_cache/posters/198851-2.jpg','https://thetvdb.com/banners/fanart/original/198851-7.jpg','')
    Menu('PAW Patrol','http://www.toonget.net/paw-patrol',2,'http://thetvdb.com/banners/_cache/posters/272472-6.jpg','http://thetvdb.com/banners/fanart/original/272472-3.jpg','')
    Menu('Peppa Pig','http://www.toonget.net/peppa-pig',2,'http://thetvdb.com/banners/_cache/posters/79222-1.jpg','http://thetvdb.com/banners/fanart/original/79222-3.jpg','')
    Menu('Peter Rabbit 2013','http://www.toonget.net/peter-rabbit',2,'http://thetvdb.com/banners/_cache/posters/267185-2.jpg','http://thetvdb.com/banners/fanart/original/267185-1.jpg','')
    Menu('Postman Pat: Special Delivery Service','http://www.toonget.net/postman-pat-special-delivery-service',2,'http://thetvdb.com/banners/_cache/posters/83719-2.jpg','http://thetvdb.com/banners/fanart/original/83719-1.jpg','')
    Menu('Rugrats','http://www.toonget.net/rugrats',2,'http://thetvdb.com/banners/_cache/posters/77038-2.jpg','http://thetvdb.com/banners/fanart/original/77038-7.jpg','')
    Menu('Sarah and Duck','http://www.toonget.net/sarah-and-duck',2,'http://thetvdb.com/banners/_cache/posters/267108-2.jpg','http://thetvdb.com/banners/fanart/original/267108-2.jpg','')   
    Menu('Shaun the Sheep','http://www.toonget.net/shaun-the-sheep',2,'http://thetvdb.com/banners/_cache/posters/79890-2.jpg','http://thetvdb.com/banners/fanart/original/79890-2.jpg','')
    Menu('The Simpsons','http://www.kisspanda.net/the-simpsons/',1,'http://thetvdb.com/banners/_cache/posters/71663-15.jpg','http://thetvdb.com/banners/fanart/original/71663-25.jpg','')
    Menu('The Smurfs','http://www.toonget.net/the-smurfs',2,'http://thetvdb.com/banners/_cache/posters/75719-7.jpg','http://thetvdb.com/banners/fanart/original/75719-1.jpg','')
    Menu('Thunderbirds Are Go!','http://www.toonget.net/thunderbirds-are-go',2,'http://thetvdb.com/banners/_cache/posters/266631-5.jpg','http://thetvdb.com/banners/fanart/original/266631-5.jpg','')
    Menu('South Park','http://www.kisspanda.net/south-park/',1,'http://thetvdb.com/banners/_cache/posters/75897-2.jpg','http://thetvdb.com/banners/fanart/original/75897-44.jpg','')
    Menu('Spider-Man (1984)','http://www.toonget.net/spider-man-the-animated-series',2,'http://thetvdb.com/banners/_cache/posters/73750-5.jpg','http://thetvdb.com/banners/fanart/original/73750-2.jpg','')
    Menu('SpongeBob SquarePants','http://www.toonget.net/spongebob-squarepants',2,'http://thetvdb.com/banners/_cache/posters/75886-5.jpg','http://thetvdb.com/banners/fanart/original/75886-10.jpg','')
    Menu('Thomas the Tank Engine & Friends','http://www.toonget.net/thomas-the-tank-engine-friends',2,'http://thetvdb.com/banners/_cache/posters/78949-3.jpg','http://thetvdb.com/banners/fanart/original/78949-8.jpg','')
    Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]','',3,ART + 'nextpage.jpg',FANART,'')	
    xbmc.executebuiltin('Container.SetViewMode(500)')

def extra_menu():
    OPEN = Open_Url('https://raw.githubusercontent.com/dandy0850/iStream/master/test/toons.txt')
    Regex = re.compile('<title>(.+?)</title>.+?url>(.+?)</url>.+?thumb>(.+?)</thumb>.+?art>(.+?)</art>',re.DOTALL).findall(OPEN)
    for name,url,icon,fanart in Regex:
            Menu(name,url,2,icon,fanart,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

	
def Second_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<a title="(.+?)" href="(.+?)">',re.DOTALL).findall(OPEN)
    for name,url in Regex:
            name = name.replace('&#8217;','')
            Play(name,url,100,iconimage,fanart,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Alt_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('&nbsp;&nbsp;<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in Regex:
            name = name.replace('&#8217;','')
            Play(name,url,100,iconimage,fanart,'')
    np = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in np:
            if 'Next' in name:
                    Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,2,iconimage,fanart,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

	########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    OPEN = Open_Url(url)
    url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
    play=urlresolver.HostedMediaFile(url).resolve()
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_Menu()
elif mode == 1 : Second_Menu(url)
elif mode == 2 : Alt_Menu(url)
elif mode == 3 : extra_menu()
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
