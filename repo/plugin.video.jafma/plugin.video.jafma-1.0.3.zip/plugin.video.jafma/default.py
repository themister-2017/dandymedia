# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os
import urlresolver
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.jafma/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'jafma'
VERSION = '1.0.3'
BASEURL = 'http://movie4u.cc/'
ART = ADDON_PATH + "resources/icons/"



def Main_menu():
    Menu('[B][COLOR orange]Trending[/COLOR][/B]',BASEURL+'trending/?get=movies',5,ART + 'trending.jpg',FANART,'')
    Menu('[B][COLOR orange]Ratings[/COLOR][/B]',BASEURL+'ratings/?get=movies',5,ART + 'rate.jpg',FANART,'')
    Menu('[B][COLOR orange]IMDB Top Movies[/COLOR][/B]',BASEURL+'top-imdb/',7,ART + 'imdb_mov.jpg',FANART,'')
    Menu('[B][COLOR orange]All Movies[/COLOR][/B]',BASEURL+'movies/',5,ART + 'allmov.jpg',FANART,'')
    Menu('[B][COLOR orange]Genres[/COLOR][/B]',BASEURL,3,ART + 'genres.jpg',FANART,'')
    Menu('[B][COLOR orange]Release Year[/COLOR][/B]',BASEURL,4,ART + 'rel_year.jpg',FANART,'')
    Menu('[B][COLOR orange]TV Shows[/COLOR][/B]',BASEURL+'tvshows/',8,ART + 'tv_show.jpg',FANART,'')
    Menu('[B][COLOR orange]IMDB Top TV[/COLOR][/B]',BASEURL+'top-imdb/',2,ART + 'imdb_tv.jpg',FANART,'')
    Menu('[B][COLOR orange]Search[/COLOR][/B]','url',6,ART + 'searchall.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="genres scrolling">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)" >(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            name = name.replace('amp;','')
            if 'Action & Adventure' not in name:
                Menu('[B][COLOR orange]%s[/COLOR][/B]' %name,url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Years(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="year scrolling">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR orange]%s[/COLOR][/B]' %name,url,5,ART + 'rel_year.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<article id=".+?" class="item movies".+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('-185x278','')
            name = name.replace('&#8217;','\'').replace('#038;','').replace('\\xc3\\xa9','e').replace('&#8211;','-')
            Menu('[B][COLOR orange]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile('class="current".+?<a href=\'(.+?)\'',re.DOTALL).findall(OPEN)
    for url in np:
                    Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_imdb(url):
    OPEN = Open_Url(url)
    Regex = re.compile('</i> Movies</h3>(.+?)<div class="top-imdb-list">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<div class="image">.+?<img src="(.+?)" /></a>.+?<a href="(.+?)">(.+?)</a></div>',re.DOTALL).findall(str(Regex))
    for icon,url,name in Regex2:
            icon = icon.replace('-90x135','')
            name = name.replace('&#8211;','-').replace('#038;','').replace('\\xc3\\xa9','e').replace('&#8217;','\'')
            Menu('[B][COLOR orange]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_tv_imdb(url):
    OPEN = Open_Url(url)
    Regex = re.compile('TV Shows</h3>(.+?)<footer class="main">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<img src="(.+?)".+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for icon,url,name in Regex2:
            icon = icon.replace('-90x135','')
            name = name.replace('&#8217;','').replace('#038;','').replace('\\xc3\\xa9','e').replace('&#039;','\'')
            Menu('[B][COLOR orange]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_TV(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<article id=".+?" class="item tvshows".+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('-185x278','')
            name = name.replace('&#8217;','\'')
            Menu('[B][COLOR orange]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')
    np = re.compile('class="current".+?<a href=\'(.+?)\'',re.DOTALL).findall(OPEN)
    for url in np:
                    Menu('[B][COLOR blue]Next Page>>>[/COLOR][/B]',url,8,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_show_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="imagen">.+?<img src="(.+?)"></a>.+?<div class="numerando">(.+?)</div>.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for icon,name1,url,name2 in Regex:
            name = name1+'   '+name2
            name = name.replace('&#039;','\'')
            Menu('[B][COLOR orange]%s[/COLOR][/B]' %name,url,10,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

	
def Get_links(name,url):
    OPEN = Open_Url(url)
    trailer = re.compile('<iframe.+?src="https://www.youtube.com/embed/(.+?)\?rel=0&amp;controls=1&amp;showinfo=0&autoplay=0"',re.DOTALL).findall(OPEN)
    for url in trailer:
            Play('[B][COLOR red]Play Trailer[/COLOR][/B]','plugin://plugin.video.youtube/play/?video_id=%s'%url,100,iconimage,FANART,name)
    Regex = re.compile('file:"(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
            Play('[B][COLOR white]GoogleLink[/COLOR][/B]',url,100,iconimage,FANART,name)
    server2 = re.compile('src="https://openload.co/embed/(.+?)"',re.DOTALL).findall(OPEN)
    for url in server2:
            Play('[B][COLOR white]Openload[/COLOR][/B]','https://openload.co/f/%s'%url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')	

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?s=' + search
                search_res(url)
    
def search_res(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="result-item">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.replace('&#8217;','').replace('#038;','')
            icon = icon.replace('w90','w300_and_h450_bestv2')
            if '/tvshows/' in url:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')    
            else:
                Play('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')  
	
########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    name = description
    xbmc.executebuiltin("XBMC.Notification([COLOR orange]Attempting[/COLOR],[COLOR orange]To Resolve Link[/COLOR] ,2000)")
    if 'openload.co' in url:
        play=urlresolver.HostedMediaFile(url).resolve()
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
        liz.setProperty('IsPlayable','true')
        xbmc.Player().play(play,liz)
    else:   
        try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
        except:
            play=xbmc.Player(GetPlayerCore())
            play.play(url,liz)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 2 : Get_tv_imdb(url)
elif mode == 3: Get_Genres(url)
elif mode == 4: Get_Years(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 7 : Get_imdb(url)
elif mode == 8 : Get_TV(url)
elif mode == 9 : Get_show_content(url)
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
