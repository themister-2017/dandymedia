# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy
import urlresolver
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.moviemadness/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'moviemadness'
VERSION = '1.0.0'
BASEURL = 'https://torba.se'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR white]Recently Added Movies[/COLOR][/B]','https://torba.se/search?order=recent&language[]=English',5,ART + 'recent.jpg',FANART,'')
    Menu('[B][COLOR white]Popular Movies[/COLOR][/B]','https://torba.se/search?order=views&language[]=English',5,ART + 'popular.jpg',FANART,'')
    Menu('[B][COLOR white]Favourite Movies[/COLOR][/B]','https://torba.se/search?order=favorites&language[]=English',5,ART + 'favourite.jpg',FANART,'')
    Menu('[B][COLOR white]Release Year[/COLOR][/B]','',4,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]Movie Genres[/COLOR][/B]','',3,ART + 'mov_gen.jpg',FANART,'')
    Menu('[B][COLOR white]Search Movies[/COLOR][/B]','url',6,ART + 'search_mov.jpg',FANART,'')
    Menu('[B][COLOR red]Latest TV Episodes[/COLOR][/B]','https://torba.se/series',8,ART + 'latest_tv.jpg',FANART,'')
    Menu('[B][COLOR red]TV Shows[/COLOR][/B]','',7,ART + 'tv_shows.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres():
    OPEN = Open_Url('https://torba.se/search')
    Regex = re.compile('<a class="header-filter-sorting-item-link">All genres</a>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li class="dropdown-item">.+?data-parentid="dropdown-id-genre">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for name in Regex2:
        if 'All genres' not in name:
            url='https://torba.se/search?order=recent&genre=' + name + '&language[]=English'
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'mov_gen.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Release_Year():
    OPEN = Open_Url('https://torba.se/search')
    Regex = re.compile('<a class="header-filter-sorting-item-link">All years</a>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li class="dropdown-item">.+?data-parentid="dropdown-id-year">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for name in Regex2:
        if 'All years' not in name:
            url='https://torba.se/search?order=recent&year=' + name + '&language[]=English'
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'release.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="films-item-image">.+?<a href="(.+?)"><img src="(.+?)".+?<div class="films-item-title"><span>(.+?)</span></div>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&amp;','&')
            icon = icon.replace('_small','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,'https://torba.se%s'%url,10,'https://torba.se%s'%icon,FANART,'')
    np = re.compile('<li class="next"><a href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        url = url.replace('amp;','')
        Menu('[B][COLOR yellow]Next Page>>>[/COLOR][/B]','https://torba.se%s'%url,5,ART + 'pagenext.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
		
def TV_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="episode-item-image">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)">',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.replace('Watch ','').replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&amp;','&')
            icon = icon.replace('_small','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,'https://torba.se%s'%url,10,'https://torba.se%s'%icon,FANART,'')
    np = re.compile('<li class="next"><a href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        url = url.replace('amp;','')
        Menu('[B][COLOR yellow]Next Page>>>[/COLOR][/B]','https://torba.se%s'%url,8,ART + 'pagenext.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def TV_shows():
    Menu('[B][COLOR white]Popular Shows[/COLOR][/B]','https://torba.se/series/search?order=views',9,ART + 'pop_tv.jpg',FANART,'')
    Menu('[B][COLOR white]User TV Picks[/COLOR][/B]','https://torba.se/series/search?order=followed',9,ART + 'user_tv.jpg',FANART,'')
    Menu('[B][COLOR white]Highest Rated Shows[/COLOR][/B]','https://torba.se/series/search?order=rating',9,ART + 'rated_tv.jpg',FANART,'')
    Menu('[B][COLOR white]Shows Alphabetical[/COLOR][/B]','https://torba.se/series/search?order=name',9,ART + 'tv_alpha.jpg',FANART,'')
    Menu('[B][COLOR white]TV Show Genres[/COLOR][/B]','',21,ART + 'show_genres.jpg',FANART,'')
    Menu('[B][COLOR red]Search for a Show[/COLOR][/B]','url',50,ART + 'search_tv.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_tvshows(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="tv-show-poster" style="background-image:url\((.+?)\)"></div>.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&amp;','&')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,'https://torba.se%s'%url,15,'https://torba.se%s'%icon,FANART,'')
    np = re.compile('<li class="next"><a href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        url = url.replace('amp;','')
        Menu('[B][COLOR yellow]Next Page>>>[/COLOR][/B]','https://torba.se%s'%url,9,ART + 'pagenext.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

def TV_Genres():
    OPEN = Open_Url('https://torba.se/series/all')
    Regex = re.compile('<a class="header-filter-sorting-item-link">All genres</a>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li class="dropdown-item">.+?data-parentid="dropdown-id-genre">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for name in Regex2:
        name=name.replace('</a></li><li class="dropdown-item"><a data-text="Drama" data-value="Drama" data-hiddenid="id-genre" data-parentid="dropdown-id-genre">Drama','Drama')
        url='https://torba.se/series/search?order=recent&genre=' + name
        Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,9,ART + 'show_genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')    

def Get_seasons(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="season-list">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,'https://torba.se%s'%url,20,iconimage,iconimage,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="episode-item-image">.+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('&#039;','\'')
            name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&amp;','&').replace('Watch ','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,'https://torba.se%s'%url,10,'https://torba.se%s'%icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')
	
def Get_links(name,url):
    OPEN = Open_Url(url)
    trailer = re.compile('<a class="play-trailer-link".+?data-url="(.+?)"',re.DOTALL).findall(OPEN)
    for link in trailer:
            Play('[B][COLOR red]Play Trailer[/COLOR][/B]',link,100,iconimage,FANART,name)
    Regex = re.compile('<a class="video-play.+? href="(.+?)"',re.DOTALL).findall(OPEN)
    for get_url in Regex:
            get_url = get_url.replace('view','embed')
            link2 = Open_Url(get_url)
            vid = re.compile('"src":"(.+?)"').findall(link2)
    for url in vid:
        if '/1080p/' in url:
            Play('[B][COLOR white]Play in 1080p[/COLOR][/B]',url,100,iconimage,FANART,name)
        elif '/720p/' in url:
            Play('[B][COLOR white]Play in 720p[/COLOR][/B]',url,100,iconimage,FANART,name)
        elif '/360p/' in url:
            Play('[B][COLOR white]Play in 360p[/COLOR][/B]',url,100,iconimage,FANART,name)
        else:pass
    xbmc.executebuiltin('Container.SetViewMode(50)')



def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'https://torba.se/search?title=' + search 
                Get_content(url)
    
def TV_Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'https://torba.se/series/search?title=' + search 
                Get_tvshows(url)
                
########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    name = description
    xbmc.executebuiltin("XBMC.Notification([COLOR blue]Attempting to[/COLOR],[COLOR red]Resolve Link[/COLOR] ,3000)")
    OPEN = Open_Url(url) 
    play=urlresolver.HostedMediaFile(url).resolve()
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################

if mode == None: Main_menu()
elif mode == 3 : Get_Genres()
elif mode == 4 : Release_Year()
elif mode == 5 : Get_content(url)
elif mode == 9 : Get_tvshows(url)
elif mode == 6 : Search()
elif mode == 50 : TV_Search()
elif mode == 7 : TV_shows()
elif mode == 8 : TV_content(url)
elif mode == 15 : Get_seasons(url)
elif mode == 20 : Get_episodes(url)
elif mode == 21 : TV_Genres()
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
