# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.moviezone/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'moviezone'
VERSION = '1.1.4'
BASEURL = 'http://moovies.online/'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR chartreuse]Trending Movies[/COLOR][/B]',BASEURL+'trending/',5,ART + 'trending.jpg',FANART,'')
    Menu('[B][COLOR chartreuse]Rated Movies[/COLOR][/B]',BASEURL+'ratings/?get=movies',5,ART + 'rating.jpg',FANART,'')
    Menu('[B][COLOR chartreuse]IMDB Top Movies[/COLOR][/B]',BASEURL+'top-imdb/',7,ART + 'imdb_mov.jpg',FANART,'')
    Menu('[B][COLOR chartreuse]All Movies[/COLOR][/B]',BASEURL+'movies/',5,ART + 'movsall.jpg',FANART,'')
    Menu('[B][COLOR chartreuse]Genres[/COLOR][/B]',BASEURL,3,ART + 'allgenres.jpg',FANART,'')
    Menu('[B][COLOR chartreuse]Release Year[/COLOR][/B]',BASEURL,4,ART + 'rel_year.jpg',FANART,'')
    Menu('[B][COLOR chartreuse]TV Shows[/COLOR][/B]',BASEURL+'tvshows/',8,ART + 'tv_shows.jpg',FANART,'')
    Menu('[B][COLOR chartreuse]IMDB Top TV[/COLOR][/B]',BASEURL+'top-imdb/',2,ART + 'imdb_tv.jpg',FANART,'')
    Menu('[B][COLOR chartreuse]Search[/COLOR][/B]','url',6,ART + 'search_all.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h2>Genres</h2>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)" >(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            name = name.replace('amp;','')
            Menu('[B][COLOR chartreuse]%s[/COLOR][/B]' %name,url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Years(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h2>Release Year</h2>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR chartreuse]%s[/COLOR][/B]' %name,url,5,ART + 'release.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_content(url):    
    OPEN = Open_Url(url)
    Regex = re.compile('class="item movies".+?href="(.+?)">.+?src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('w185','w300_and_h450_bestv2')
            name = name.replace('&#8217;','\'').replace('&#8211;','').replace('#038;','')
            Play('[B][COLOR chartreuse]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    np = re.compile('class="current".+?href=\'(.+?)\'',re.DOTALL).findall(OPEN)
    for url in np:
                    Menu('[B][COLOR green]Next Page>>>[/COLOR][/B]',url,5,ART + 'page_next.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_imdb(url):
    OPEN = Open_Url(url)
    Regex = re.compile('</i> Movies</h3>(.+?)class="top-imdb-list">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('class="poster">.+?src="(.+?)".+?href="(.+?)">(.+?)</a></div>',re.DOTALL).findall(str(Regex))
    for icon,url,name in Regex2:
            icon = icon.replace('w90','w300_and_h450_bestv2')
            name = name.replace('&#8217;','').replace('#038;','').replace('\\xc3\\xa9','e').replace('&#8211;','')
            Play('[B][COLOR chartreuse]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')    

def Get_tv_imdb(url):
    OPEN = Open_Url(url)
    Regex = re.compile('TV Shows</h3>(.+?)<footer class="main">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<img src="(.+?)".+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for icon,url,name in Regex2:
            icon = icon.replace('w90','w300_and_h450_bestv2')
            name = name.replace('&#8217;','').replace('#038;','').replace('\\xc3\\xa9','e').replace('&#039;','\'')
            Menu('[B][COLOR chartreuse]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_TV(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="item tvshows".+?href="(.+?)">.+?src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('w185','w300_and_h450_bestv2')
            name = name.replace('&#8217;','').replace('&#039;','\'').replace('&#8211;','')
            Menu('[B][COLOR chartreuse]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')
    np = re.compile('class="current".+?href=\'(.+?)\'',re.DOTALL).findall(OPEN)
    for url in np:
                    Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,8,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_show_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="imagen">.+?src="(.+?)"></a>.+?class="numerando">(.+?)</div>.+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for icon,name1,url,name2 in Regex:
            name = name1+'   '+name2
            name = name.replace('&#039;','\'')
            Play('[B][COLOR chartreuse]%s[/COLOR][/B]' %name,url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
  
#def Get_links(name,url):
#    OPEN = Open_Url(url)
#    Regex = re.compile('<iframe style.+?src="(.+?)"',re.DOTALL).findall(OPEN)
#    for link in Regex:
#        link = 'http:' + link
#        endlinks= Open_Url(link)
#        vids=re.compile('file: "(.+?)",label:"(.+?)"',re.DOTALL).findall(endlinks)
#    for url,name2 in vids:
#            Play('[B][COLOR chartreuse]Play in %s[/COLOR][/B]'%name2,url,100,iconimage,FANART,name)
 #   xbmc.executebuiltin('Container.SetViewMode(50)')

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '?s=' + search
                search_res(url)
    
def search_res(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="result-item">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.replace('&#8217;','').replace('#038;','').replace('&#8211;','').replace('&#039;','\'')
            icon = icon.replace('w90','w300_and_h450_bestv2')
            if '/tvshows/' in url:
                Menu('[B][COLOR chartreuse]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')    
            else:
                Play('[B][COLOR chartreuse]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')  
				

########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
 


 

def resolve(name,url,iconimage,description):
    xbmc.executebuiltin("XBMC.Notification([COLOR chartreuse]Attempting[/COLOR],[COLOR chartreuse]To Resolve Link[/COLOR] ,2000)")
    OPEN = Open_Url(url)
    link = re.compile('<iframe style.+?src="(.+?)"',re.DOTALL).findall(OPEN)[0]
    news = 'http:' + link
    endlinks= Open_Url(news)
    url=re.compile('file: "(.+?)"',re.DOTALL).findall(endlinks)[0]
     
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(url,liz)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 2 : Get_tv_imdb(url)
elif mode == 3: Get_Genres(url)
elif mode == 4: Get_Years(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 7 : Get_imdb(url)
elif mode == 8 : Get_TV(url)
elif mode == 9 : Get_show_content(url)
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
