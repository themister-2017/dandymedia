# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.movieaddictz_gw/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'movieaddictz_gw'
VERSION = '1.0.3'
BASEURL = 'http://vumoo.li'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR red]Popular This Week[/COLOR][/B]',BASEURL + '/videos/category/popular-this-week',5,ART + 'popular.jpg',FANART,'')
    Menu('[B][COLOR red]Currently Watching[/COLOR][/B]',BASEURL + '/videos/category/currently-watching',5,ART + 'current.jpg',FANART,'')
    Menu('[B][COLOR red]Recently Added[/COLOR][/B]',BASEURL + '/videos/category/recently-added',5,ART + 'recent.jpg',FANART,'')
    Menu('[B][COLOR red]New Releases[/COLOR][/B]',BASEURL + '/videos/category/new-releases',5,ART + 'new_rel.jpg',FANART,'')
    Menu('[B][COLOR red]IMDB Top Rated[/COLOR][/B]',BASEURL + '/videos/category/top-rated-imdb',5,ART + 'imdb.jpg',FANART,'')
    Menu('[B][COLOR red]Movie by Genre[/COLOR][/B]','',8,ART + 'genre.jpg',FANART,'')
    Menu('[B][COLOR red]Search for a Movie[/COLOR][/B]','url',6,ART + 'search_mov.jpg',FANART,'')
    Menu('[B][COLOR blue]Trending TV[/COLOR][/B]',BASEURL + '/videos/category/trending-television',2,ART + 'trendingtv.jpg',FANART,'')
    Menu('[B][COLOR blue]Search for a TV Show[/COLOR][/B]','url',7,ART + 'TV_search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="slick-slide.+?<a href="(.+?)".+?data-title="(.+?)".+?style="background-image: url\((.+?)\);',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        if 'Da Vinci' not in name:
            Play('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + '/%s'%url,100,icon,FANART,'')
    np = re.compile('<div class="navigation"> <a href="(.+?)">',re.DOTALL).findall(OPEN)
    for url in np:
            Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]',BASEURL + '/%s'%url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_genres():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('<ul class="multi-column-dropdown">(.+?)</ul> </div> </div> </ul> </div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR red]%s[/COLOR][/B]' %name,BASEURL + '/%s'%url,5,ART + 'genre.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_TV(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="slick-slide.+?<a href="(.+?)".+?data-title="(.+?)".+?style="background-image: url\((.+?)\);',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex: 
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + '/%s'%url,3,icon,FANART,'')
    np = re.compile('<div class="navigation"> <a href="(.+?)">',re.DOTALL).findall(OPEN)
    for url in np:
            Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]',BASEURL + '/%s'%url,2,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_episode(url):
    OPEN = Open_Url(url)
    Regex = re.compile(' <li id=season.+?<h2>(.+?)</h2> <span class="season-info">(.+?)</span>.+?<span class="season-info air-date">(.+?)</span>.+?data-click=" (.+?)"',re.DOTALL).findall(OPEN)
    for info,epis,airdate,url in Regex:
            airdate=airdate.replace('Air date: ','')
            name = epis + ' - ' + info + ' - [COLOR red]' + airdate
            Play('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

    
def Search():
        keyb = xbmc.Keyboard('', 'Search for a Movie')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + "/videos/search/?search=" + search
                Get_content(url)

def Search_TV():
        keyb = xbmc.Keyboard('', 'Search for a TV Show')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + "/videos/search/?search=" + search
                Get_TV(url)
########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def normalresolve(name,url,iconimage,description):  #change back when google back up
    if 'openload' in url:
        xbmc.executebuiltin("XBMC.Notification([COLOR red]Attempting to Resolve[/COLOR],[COLOR blue]Openload Link[/COLOR] ,5000)") 
        play=urlresolver.resolve(url)   
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
        liz.setProperty('IsPlayable','true')
        xbmc.Player().play(play,liz)
    else:
        OPEN = Open_Url(url)
        try:
            url = re.compile('mainServer server-button active-server" data-url="(.+?)"',re.DOTALL).findall(OPEN)[0]
            if 'google' in url:
                url = url.replace('\n','').replace('https://docs.google.com/uc?id=','https://drive.google.com/file/d/').replace('uc?id=','file/d/').replace('&export=download','/edit')
                xbmc.executebuiltin("XBMC.Notification([COLOR red]Resolving Direct[/COLOR],[COLOR blue]Google Link[/COLOR] ,2000)")
                play=urlresolver.resolve(url)
                liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
                liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
                liz.setProperty('IsPlayable','true')
                xbmc.Player().play(play,liz)
            else:  
                url = url.replace('_p_','')
                xbmc.executebuiltin("XBMC.Notification([COLOR red]Resolving Direct[/COLOR],[COLOR blue]Google Link[/COLOR] ,2000)")
                url = 'http://vumoo.li/api/plink?id=' + url + '&res=720'
                liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
                liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
                liz.setProperty('IsPlayable','true')
                play=xbmc.Player(GetPlayerCore())
                play.play(str(url),liz)                
    
        except:
            url = re.compile("openloadLink = '(.+?)'",re.DOTALL).findall(OPEN)[0]
            xbmc.executebuiltin("XBMC.Notification([COLOR red]Attempting to Resolve[/COLOR],[COLOR blue]Back up Link Openload[/COLOR] ,2000)")
            play=urlresolver.resolve(url)

def resolve(name,url,iconimage,description): ####delete this resolve once google back
    OPEN = Open_Url(url)
    url = re.compile("openloadLink = '(.+?)'",re.DOTALL).findall(OPEN)[0]
    xbmc.executebuiltin("XBMC.Notification([COLOR red]Attempting to Resolve[/COLOR],[COLOR blue]Back up Link Openload[/COLOR] ,2000)")
    play=urlresolver.resolve(url)    
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)

        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 2 : Get_TV(url)
elif mode == 3 : Get_episode(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 7 : Search_TV()
elif mode == 8 : Get_genres()
elif mode == 100 : resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
