# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.watchoverhere/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'watchoverhere'
VERSION = '1.0.4'
BASEURL = 'http://oneclickmovies.tv/'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR blue]Latest Added Movies[/COLOR][/B]',BASEURL + 'movies/date/1',5,ART + 'latestmovie.jpg',FANART,'')
    Menu('[B][COLOR blue]Featured Movies[/COLOR][/B]',BASEURL + 'movies/featured',5,ART + 'feamov.jpg',FANART,'')
    Menu('[B][COLOR blue]Popular Movies[/COLOR][/B]',BASEURL + 'movies/views',5,ART + 'popmov.jpg',FANART,'')
    Menu('[B][COLOR blue]IMDB Rating Movies[/COLOR][/B]',BASEURL + 'movies/imdb_rating',5,ART + 'imdbmov.jpg',FANART,'')
    Menu('[B][COLOR blue]Random Movies[/COLOR][/B]',BASEURL + 'movies/random',5,ART + 'ranmov.jpg',FANART,'')
    Menu('[B][COLOR blue]Movie Genres[/COLOR][/B]',BASEURL + 'movies',3,ART + 'movgen.jpg',FANART,'')
    Menu('[B][COLOR blue]Latest Added TV[/COLOR][/B]',BASEURL + 'tv-shows/date',6,ART + 'lattv.jpg',FANART,'')
    Menu('[B][COLOR blue]Featured TV[/COLOR][/B]',BASEURL + 'tv-shows/featured',6,ART + 'featTV.jpg',FANART,'')
    Menu('[B][COLOR blue]Popular TV[/COLOR][/B]',BASEURL + 'tv-shows/views',6,ART + 'poptv.jpg',FANART,'')
    Menu('[B][COLOR blue]Newest TV[/COLOR][/B]',BASEURL + 'tv-shows/id',6,ART + 'newtv.jpg',FANART,'')
    Menu('[B][COLOR blue]IMDB Rating TV[/COLOR][/B]',BASEURL + 'tv-shows/imdb_rating',6,ART + 'imdbTV.jpg',FANART,'')
    Menu('[B][COLOR blue]TV Genres[/COLOR][/B]',BASEURL + 'tv-shows',4,ART + 'tvgen.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<select class="filter"(.+?)</select>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<option value="(.+?)">(.+?)</option>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,5,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_TVGenres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<select class="filter"(.+?)</select>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<option value="(.+?)">(.+?)</option>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,6,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('div class="card".+?<a href="(.+?)" taget="_blank">.+?src=(.+?)&w=200&h=300.+?<div class="card__name">(.+?)</div>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile('<ul class="pagination">(.+?)<div class="container">',re.DOTALL).findall(OPEN)
    np2 = re.compile('href="(.+?)">(.+?)</a',re.DOTALL).findall(str(np))
    for url,name in np2:
            if 'right' in name:
                Menu('[B][COLOR cyan]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def TV_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="grid-item col-xs-4 col-md-2 col-sm-3".+?<a href="(.+?)".+?src=(.+?)&w=200&h=300.+?<div class="card__name">(.+?)</div>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,8,icon,FANART,'')
    np = re.compile('<ul class="pagination">(.+?)<div class="container">',re.DOTALL).findall(OPEN)
    np2 = re.compile('href="(.+?)">(.+?)</a',re.DOTALL).findall(str(np))
    for url,name in np2:
            if 'right' in name:
                Menu('[B][COLOR cyan]Next Page>>>[/COLOR][/B]',url,6,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Seasons(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<strong>Seasons</strong>(.+?)<div class="hidden-xs">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)".+?<span style="color:#23a8f5">SEASON</span>(.+?)</span>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR blue]Season%s[/COLOR][/B]' %name,url,8,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<a class="list-group-item" href="(.+?)".+?</a>',re.DOTALL).findall(OPEN)
    for url in Regex:
            name = url
            name = name.replace('http://oneclickmovies.tv/show/','').title()
            name = name.replace('-',' ').replace('/Season/',' [B][COLOR red](Season ').replace('/Episode/',' - Episode ')
            Menu('[B][COLOR blue]%s)[/COLOR][/B]' %name,url,10,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
   
def Get_links(name,url):
    referer = url
    headers = {'Host': 'watchoverhere.tv', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<table class="table table-hover visible-xs".+?src="http://www.google.com/s2/favicons\?domain\_url=(.+?)" alt="(.+?)">',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
        if 'watchoverhere.tv' in name2:
            name2 = name2.replace('watchoverhere.tv','[COLOR cyan]GoogleLinks[/COLOR]')
            Menu('[B][COLOR white]%s[/COLOR][/B]'%name2,url,12,iconimage,FANART,name)
        if 'vidlox.tv' in name2:
            LINK = Open_Url(url)
            Regex2 = re.compile('sources:.+?file:"(.+?)"',re.DOTALL).findall(LINK)
            for url in Regex2:
                Play('[B][COLOR white]%s[/COLOR][/B]'%name2,url,100,iconimage,FANART,name)
        else:
            if urlresolver.HostedMediaFile(url):
                    Play('[B][COLOR white]%s[/COLOR][/B]'%name2,url,150,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def get_google(name,url):
    name = description
    referer = url
    headers = {'Host': 'watchoverhere.tv', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile("file:'(.+?)',label:'(.+?)'",re.DOTALL).findall(OPEN)
    for url,name2 in Regex:  
            Play('[B][COLOR cyan]GoogleLink in %s[/COLOR][/B]'%name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')
  

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))



def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    name = description
    xbmc.executebuiltin("XBMC.Notification([COLOR blue]WatchOverHere[/COLOR],[COLOR blue]Resolving Link[/COLOR] ,2000)")
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def alt_resolve(name,url,iconimage,description):
    name = description
    xbmc.executebuiltin("XBMC.Notification([COLOR blue]WatchOverHere[/COLOR],[COLOR blue]Resolving Link[/COLOR] ,2000)") 
    play=urlresolver.resolve(url)
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres(url)
elif mode == 4: Get_TVGenres(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : TV_content(url)
elif mode == 7 : Seasons(url)
elif mode == 8 : Episodes(url)
elif mode == 10 : Get_links(name,url)
elif mode == 12 : get_google(name,url)
elif mode == 15 : Get_TV_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)
elif mode == 150 : alt_resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
