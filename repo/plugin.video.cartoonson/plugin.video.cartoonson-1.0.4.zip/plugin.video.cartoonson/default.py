# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.cartoonson/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'cartoonson'
VERSION = '1.0.4'
BASEURL = 'http://www.cartoonson.com/'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR white]All Content[/COLOR][/B]',BASEURL,1,ART + 'allcont.jpg',FANART,'')
    Menu('[B][COLOR white]By Studio[/COLOR][/B]',BASEURL,5,ART + 'studio.jpg',FANART,'')
    Menu('[B][COLOR white]Characters[/COLOR][/B]',BASEURL,6,ART + 'char.jpg',FANART,'')
    Menu('[B][COLOR white]Series[/COLOR][/B]',BASEURL,7,ART + 'series.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

def studios(url):
    OPEN = Open_Url(url)
    Regex = re.compile('id="menu-group-id-2"(.+?)</ul>',re.DOTALL).findall(OPEN)[0]
    Regex = Regex.replace('\r','').replace('\n','').replace('\t','')
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,'http://www.cartoonson.com%s'%url,1,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def charac(url):
    OPEN = Open_Url(url)
    Regex = re.compile('id="menu-group-id-3"(.+?)</ul>',re.DOTALL).findall(OPEN)[0]
    Regex = Regex.replace('\r','').replace('\n','').replace('\t','')
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,'http://www.cartoonson.com%s'%url,1,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')  

def toons_only():
        Menu('[B][COLOR white]Race to the Edge[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/race-to-the-edge',2,'http://www.cartoonson.com/_resources/Cartoons/show/61/image/555x418/dragons_race_edge.jpg',FANART,'')
        Menu('[B][COLOR white]Dragons Defenders of Berk[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/dragons-defenders-of-berk',2,'http://www.cartoonson.com/_resources/Cartoons/show/60/image/555x418/Defenders_of_berk_1.jpg',FANART,'')
        Menu('[B][COLOR white]Dragons Riders of Berk[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/dragon-riders-of-berk',2,'http://www.cartoonson.com/_resources/Cartoons/show/59/image/555x418/dragons-riders-of-berk.jpg',FANART,'')
        Menu('[B][COLOR white]Invader ZIM[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/invader-zim-tv-series-2001-2004',2,'http://www.cartoonson.com/_resources/Cartoons/show/58/image/555x418/invader-zim-featured.jpg',FANART,'')
        Menu('[B][COLOR white]The New Batman Adventures[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-new-batman-adventures-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/57/image/555x418/The-New-Batman-Adventures.jpg',FANART,'')
        Menu('[B][COLOR white]The Best of Mr. Peabody & Sherman[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-best-of-mr-peabody-and-sherman',2,'http://www.cartoonson.com/_resources/Cartoons/show/54/image/555x418/The_Mr._Peabody__Sherman_Show_1959-1962.jpg',FANART,'')
        Menu('[B][COLOR white]The Addams Family (1992)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-addams-family-1992-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/53/image/555x418/the-addams-family-1992.jpg',FANART,'')
        Menu('[B][COLOR white]The Avengers: Earths Mightiest Heroes[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-avengers-earth-s-mightiest-heroes',2,'http://www.cartoonson.com/_resources/Cartoons/show/52/image/555x418/avenger_earths_mightiest_heroes.jpg',FANART,'')
        Menu('[B][COLOR white]Baby Looney Tunes (2001-2006)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/baby-looney-tunes-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/51/image/555x418/baby-looney-toons.jpg',FANART,'')
        Menu('[B][COLOR white]The Cleveland Show (2009–2013)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-cleveland-show-2009-2013-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/22/image/555x418/The_Cleveland_Show_.jpg',FANART,'')
        Menu('[B][COLOR white]Tom and Jerry[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/tom-and-jerry-classic-collection',2,'http://www.cartoonson.com/_resources/Cartoons/show/12/image/555x418/Tom-and-Jerry-classic.jpg',FANART,'')
        Menu('[B][COLOR white]Avatar: The Last Airbender[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/avatar-the-last-airbender',2,'http://www.cartoonson.com/_resources/Cartoons/show/8/image/555x418/avatar-the-last-airbender-episodes.jpg',FANART,'')
        Menu('[B][COLOR white]Ben 10: Omniverse[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/ben-10-omniverse',2,'http://www.cartoonson.com/_resources/Cartoons/show/9/image/555x418/Ben-10-Omniverse2.jpg',FANART,'')
        Menu('[B][COLOR white]Courage the Cowardly Dog[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/courage-the-cowardly-dog',2,'http://www.cartoonson.com/_resources/Cartoons/show/7/image/555x418/courage-the-cowardly-dog-show.jpg',FANART,'')
        Menu('[B][COLOR white]The Flintstones[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-flintstones-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/14/image/555x418/The-Flintstone-TV-series.jpg',FANART,'')
        Menu('[B][COLOR white]The Bugs Bunny Show[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-bugs-bunny-show',2,'http://www.cartoonson.com/_resources/Cartoons/show/13/image/555x418/bugs-bunny-show.jpg',FANART,'')
        Menu('[B][COLOR white]Family Guy[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/family-guy-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/18/image/555x418/family-guy.jpg',FANART,'')
        Menu('[B][COLOR white]The Legend of Korra[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-legend-of-korra',2,'http://www.cartoonson.com/_resources/Cartoons/show/27/image/555x418/the-legend-of-korra.jpg',FANART,'')
        Menu('[B][COLOR white]As Told by Ginger (TV Series)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/as-told-by-ginger-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/48/image/555x418/As_Told_By_Ginger.jpg',FANART,'')       
        Menu('[B][COLOR white]Yo Yogi! (TV Series 1991-1992)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/yo-yogi-tv-series-1991-1992',2,'http://www.cartoonson.com/_resources/Cartoons/show/47/image/555x418/Yo_Yogi_.jpg',FANART,'') 		
        Menu('[B][COLOR white]Over the Garden Wall (TV Miniseries)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/over-the-garden-wall-tv-miniseries',2,'http://www.cartoonson.com/_resources/Cartoons/show/46/image/555x418/Over_the_Garden_Wall_.jpg',FANART,'')
        Menu('[B][COLOR white]Mr. Bean - The Animated Series[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/mr-bean-the-animated-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/44/image/555x418/Mr.-Bean1.jpg',FANART,'') 		
        Menu('[B][COLOR white]Scooby-Doo, Where Are You! (1969-1978)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/scooby-doo-where-are-you-1969-1978',2,'http://www.cartoonson.com/_resources/Cartoons/show/43/image/555x418/scooby-doo-where-are-you.jpg',FANART,'')
        Menu('[B][COLOR white]The Jetsons (1962-1963)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-jetsons-tv-series-1962-1963',2,'http://www.cartoonson.com/_resources/Cartoons/show/35/image/555x418/jetsons.jpg',FANART,'')
        Menu('[B][COLOR white]The Smurfs (1981–1989)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-smurfs-tv-series-1981-1989',2,'http://www.cartoonson.com/_resources/Cartoons/show/19/image/555x418/The_Smurfs_1981.jpg',FANART,'')
        Menu('[B][COLOR white]Tom & Jerry Kids Show (1990-1994)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/tom-and-jerry-kids-show-1990-1994',2,'http://www.cartoonson.com/_resources/Cartoons/show/6/image/555x418/tom__Jerry_kids_show_.jpg',FANART,'')
        Menu('[B][COLOR white]Tom and Jerry Tales[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/tom-and-jerry-tales',2,'http://www.cartoonson.com/_resources/Cartoons/show/2/image/555x418/Tom-And-Jerry-Tales-all-volumes.jpg',FANART,'')
        Menu('[B][COLOR white]Gargoyles (1994-1996)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/gargoyles-1994-1996-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/31/image/555x418/disney-s-gargoyles.jpg',FANART,'')
        Menu('[B][COLOR white]Gravity Falls[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/gravity-falls-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/20/image/555x418/gravity-falls.jpg',FANART,'')
        Menu('[B][COLOR white]Bunnicula[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/bunnicula-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/40/image/555x418/Bunnicula_Title.jpg',FANART,'')
        Menu('[B][COLOR white]Wile E. Coyote and The Road Runner[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/wile-e-coyote-and-the-road-runner',2,'http://www.cartoonson.com/_resources/Cartoons/show/39/image/555x418/Wile_E._Coyote_and_The_Road_Runner.jpg',FANART,'')
        Menu('[B][COLOR white]We Bare Bears[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/we-bare-bears-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/42/image/555x418/we-bare-bears.jpg',FANART,'')
        Menu('[B][COLOR white]Class of 3000[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/class-of-3000-tv-series-2006',2,'http://www.cartoonson.com/_resources/Cartoons/show/36/image/555x418/Class-of-3000-Cartoon-Animation.jpg',FANART,'')
        Menu('[B][COLOR white]Adventure Time[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/adventure-time-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/32/image/555x418/adventure-time.jpg',FANART,'')
        Menu('[B][COLOR white]The Marvelous Misadventures of Flapjack[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-marvelous-misadventures-of-flapjack',2,'http://www.cartoonson.com/_resources/Cartoons/show/30/image/555x418/the_marvelous_misadventures_of_flapjack.jpg',FANART,'')
        Menu('[B][COLOR white]The Boondocks (2005)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-boondocks-tv-series-2005',2,'http://www.cartoonson.com/_resources/Cartoons/show/23/image/555x418/the-boondocks.jpg',FANART,'')
        Menu('[B][COLOR white]The Land Before Time Movies[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/the-land-before-time-movies',2,'http://www.cartoonson.com/_resources/Cartoons/show/11/image/555x418/the-land-before-time-movies.jpg',FANART,'')
        Menu('[B][COLOR white]Danny Phantom (2004-2007)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/danny-phantom-tv-series-2004-2007',2,'http://www.cartoonson.com/_resources/Cartoons/show/38/image/555x418/danny-phantom.jpg',FANART,'')
        Menu('[B][COLOR white]Sonic X (2003-2004)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/sonic-x-tv-series-2003-2004',2,'http://www.cartoonson.com/_resources/Cartoons/show/37/image/555x418/Sonic.X..jpg',FANART,'')
        Menu('[B][COLOR white]Bruno the Kid (1996-1997)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/bruno-the-kid-tv-series-1996-1997',2,'http://www.cartoonson.com/_resources/Cartoons/show/34/image/555x418/bruno-the-kid.jpg',FANART,'')
        Menu('[B][COLOR white]C Bear and Jamal (1996-1997)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/c-bear-and-jamal-tv-series-1996-1997',2,'http://www.cartoonson.com/_resources/Cartoons/show/33/image/555x418/C-Bear-and-Jamal_-1.jpg',FANART,'')
        Menu('[B][COLOR white]Justice League Unlimited (2004-2006)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/justice-league-unlimited-2004-2006',2,'http://www.cartoonson.com/_resources/Cartoons/show/29/image/555x418/justice-league-unlimited-1.jpg',FANART,'')
        Menu('[B][COLOR white]Justice League (2001-2004)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/justice-league-tv-series-2001-2004',2,'http://www.cartoonson.com/_resources/Cartoons/show/28/image/555x418/Justice_League_TV_Series_20012004.jpg',FANART,'')
        Menu('[B][COLOR white]Steven Universe[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/steven-universe-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/26/image/555x418/Steven_Universe-all_characters.jpg',FANART,'')
        Menu('[B][COLOR white]Rick and Morty[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/rick-and-morty-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/25/image/555x418/rick-and-morty.jpg',FANART,'')
        Menu('[B][COLOR white]Maggie and the Ferocious Beast[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/maggie-and-the-ferocious-beast-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/24/image/555x418/Maggie_and_the_Ferocious_Beast1.jpg',FANART,'')
        Menu('[B][COLOR white]Archer[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/archer-tv-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/21/image/555x418/archer-18817.jpg',FANART,'')
        Menu('[B][COLOR white]Black Panther (Mini-Series)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/black-panther-tv-mini-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/17/image/555x418/Black-Panther_1.jpg',FANART,'')
        Menu('[B][COLOR white]Saikano (2002)[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/saikano-2002-dub-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/49/image/555x418/saikano.jpg',FANART,'')
        Menu('[B][COLOR white]No Game No Life[/COLOR][/B]','http://www.cartoonson.com/cartoons/view/id/no-game-no-life-the-series',2,'http://www.cartoonson.com/_resources/Cartoons/show/56/image/555x418/no-game-no-life1.jpg',FANART,'')

        xbmc.executebuiltin('Container.SetViewMode(500)')
    
def page_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="image-overlay">.+?src="(.+?)".+?href="(.+?)" title="(.+?)">',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            icon = icon.replace('/336x280','')
            name = name.replace('Watch ','').replace('&#039;','\'').replace('&amp;','&').replace(' Film','')
            if 'Series' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Peabody' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Trailer' in name:
                url = url.replace('view','watch')
                Play('[B][COLOR white]%s[/COLOR][/B]' %name,url,150,icon,icon,'')
            elif 'Mightiest' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Miniseries' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Where Are You' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Wile E' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Flapjack' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Justice League Unlimeted' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Bunny Show' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Collection' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Before Time' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Animated Movies' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Omniverse' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Airbender' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Cowardly' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Kids Show' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Cinderella Films' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Volumes' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Booba' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'Dragons' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            elif 'to the Edge' in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,icon,'')
            else:
                url = url.replace('view','watch')
                Play('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,icon,'')
    np = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in np:
            if '&raquo;' in name:
                    Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,1,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')
    
def shows_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('data-parent=.+?href=".+?".+?href="(.+?)".+?<p>(.+?)</p>',re.DOTALL).findall(OPEN)
    for url,name, in Regex:
            name = name.replace('Watch ','').replace('- Cartoon for kids','').replace('online in HD','').replace('full movie','').replace('in awesome quality on any device.','').replace('in high quality','').replace('online ','').replace(' on all devices','').replace(' for free','')
            if 'Booba' in name:
                Play('[B][COLOR white]%s[/COLOR][/B]' %name,url,150,iconimage,iconimage,'')
            else:
                Play('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,iconimage,iconimage,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

    

	########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    OPEN = Open_Url(url)
    xbmc.executebuiltin("XBMC.Notification([COLOR red]Attempting to[/COLOR],[COLOR red]Resolve Link[/COLOR] ,2000)")
    url = re.compile('<source.+?src="(.+?)">',re.DOTALL).findall(OPEN)[0]
    if 'bit.ly' in url:
            headers = {'User-Agent': User_Agent}
            r = requests.get(url,headers=headers,allow_redirects=False)
            url = r.headers['location']
    else: 
        play=urlresolver.HostedMediaFile(url).resolve()
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def yt_resolve(name,url,iconimage,description):
    OPEN = Open_Url(url)
    xbmc.executebuiltin("XBMC.Notification([COLOR red]Attempting to[/COLOR],[COLOR red]Resolve Link[/COLOR] ,2000)")
    url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)[0]
    url = url[:-6]
    url = url.replace('https://www.youtube.com/embed/','plugin://plugin.video.youtube/play/?video_id=')
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 1 : page_content(url)
elif mode == 2 : shows_Menu(url)
elif mode == 5 : studios(url)
elif mode == 6 : charac(url)
elif mode == 7 : toons_only()
elif mode == 100 : resolve(name,url,iconimage,description)
elif mode == 150 : yt_resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
