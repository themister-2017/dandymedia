import urllib2 , urllib , xbmcgui , xbmcplugin , xbmc , re , sys , os , dandy
import xbmcaddon , xbmcvfs
from addon . common . addon import Addon
from md_request import open_url
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.openloadmovies'
Oo0Ooo = xbmcaddon . Addon ( id = OO0o )
O0O0OO0O0O0 = Addon ( OO0o , sys . argv )
iiiii = Oo0Ooo . getAddonInfo ( 'name' )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + '/resources/art/' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
I1IiiI = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
IIi1IiiiI1Ii = 'http://pubfilmonline.net/'
if 39 - 39: O0 - ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
if 24 - 24: II11iiII / OoOO0ooOOoo0O + o0000oOoOoO0o * i1I1ii1II1iII % oooO0oo0oOOOO
def O0oO ( ) :
 o0oO0 ( '[B][COLOR cornflowerblue]Trending[/COLOR][/B]' , IIi1IiiiI1Ii + 'trending/?get=movies' , 5 , ooo0OO + 'trend.jpg' , O00ooooo00 , '' )
 o0oO0 ( '[B][COLOR cornflowerblue]Featured[/COLOR][/B]' , IIi1IiiiI1Ii + 'genre/featured/' , 5 , ooo0OO + 'feature.jpg' , O00ooooo00 , '' )
 o0oO0 ( '[B][COLOR cornflowerblue]All Movies[/COLOR][/B]' , IIi1IiiiI1Ii + 'movies/' , 5 , ooo0OO + 'all_mov.jpg' , O00ooooo00 , '' )
 o0oO0 ( '[B][COLOR cornflowerblue]Genres[/COLOR][/B]' , IIi1IiiiI1Ii + 'ratings/' , 3 , ooo0OO + 'genres.jpg' , O00ooooo00 , '' )
 o0oO0 ( '[B][COLOR cornflowerblue]Release Year[/COLOR][/B]' , IIi1IiiiI1Ii + 'trending/' , 4 , ooo0OO + 'release.jpg' , O00ooooo00 , '' )
 o0oO0 ( '[B][COLOR cornflowerblue]IMDB Top Movies[/COLOR][/B]' , IIi1IiiiI1Ii + 'top-imdb/' , 7 , ooo0OO + 'imdb.jpg' , O00ooooo00 , '' )
 o0oO0 ( '[B][COLOR cornflowerblue]TV Shows[/COLOR][/B]' , IIi1IiiiI1Ii + 'tvseries/' , 8 , ooo0OO + 'tv_shows.jpg' , O00ooooo00 , '' )
 o0oO0 ( '[B][COLOR cornflowerblue]IMDB Top TV[/COLOR][/B]' , IIi1IiiiI1Ii + 'top-imdb/' , 2 , ooo0OO + 'tv_imdb.jpg' , O00ooooo00 , '' )
 o0oO0 ( '[B][COLOR cornflowerblue]Search[/COLOR][/B]' , 'url' , 6 , ooo0OO + 'search.jpg' , O00ooooo00 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 100 - 100: i11Ii11I1Ii1i
def Ooo ( url ) :
 o0oOoO00o = open_url ( url ) . content
 i1 = re . compile ( '<article id=.+?class="item movies".+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"' , re . DOTALL ) . findall ( o0oOoO00o )
 for url , oOOoo00O0O , i1111 in i1 :
  oOOoo00O0O = oOOoo00O0O . replace ( 'w185' , 'w300_and_h450_bestv2' )
  i1111 = i1111 . replace ( '&#8217;' , '\'' ) . replace ( '#038;' , '' ) . replace ( '\\xc3\\xa9' , 'e' ) . replace ( '&#8211;' , '-' )
  o0oO0 ( '[B][COLOR white]%s[/COLOR][/B]' % i1111 , url , 100 , oOOoo00O0O , O00ooooo00 , '' )
 i11 = re . compile ( 'class=.+?current.+?<a href=\'(.+?)\'' , re . DOTALL ) . findall ( o0oOoO00o )
 for url in i11 :
  o0oO0 ( '[B][COLOR blue]Next Page>>>[/COLOR][/B]' , url , 5 , ooo0OO + 'nextpage.jpg' , O00ooooo00 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 41 - 41: O00o0o0000o0o . oOo0oooo00o * I1i1i1ii - IIIII
def I1 ( url ) :
 o0oOoO00o = open_url ( url ) . content
 i1 = re . compile ( '<ul class="genres scrolling">(.+?)</ul>' , re . DOTALL ) . findall ( o0oOoO00o )
 O0OoOoo00o = re . compile ( '<a href="(.+?)"' , re . DOTALL ) . findall ( str ( i1 ) )
 for url in O0OoOoo00o :
  i1111 = url . split ( '/' ) [ 4 ]
  i1111 = i1111 . split ( '/' ) [ 0 ] . split ( '.' ) [ 0 ] . title ( )
  o0oO0 ( '[B][COLOR cornflowerblue]%s[/COLOR][/B]' % i1111 , url , 5 , ooo0OO + 'genres.jpg' , O00ooooo00 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 31 - 31: i111IiI + iIIIiI11 . iII111ii
def i1iIIi1 ( url ) :
 o0oOoO00o = open_url ( url ) . content
 i1 = re . compile ( '<ul class="year scrolling">(.+?)</ul>' , re . DOTALL ) . findall ( o0oOoO00o )
 O0OoOoo00o = re . compile ( '<li><a href="(.+?)">(.+?)</a></li>' , re . DOTALL ) . findall ( str ( i1 ) )
 for url , i1111 in O0OoOoo00o :
  o0oO0 ( '[B][COLOR cornflowerblue]%s[/COLOR][/B]' % i1111 , url , 5 , II1 , O00ooooo00 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 50 - 50: i11iIiiIii - I1i1i1ii
def oo0Ooo0 ( url ) :
 o0oOoO00o = open_url ( url ) . content
 i1 = re . compile ( '</i> Movies</h3>(.+?)<div class="top-imdb-list">' , re . DOTALL ) . findall ( o0oOoO00o )
 O0OoOoo00o = re . compile ( '<div class="image">.+?<img src="(.+?)" /></a>.+?<a href="(.+?)">(.+?)</a></div>' , re . DOTALL ) . findall ( str ( i1 ) )
 for oOOoo00O0O , url , i1111 in O0OoOoo00o :
  oOOoo00O0O = oOOoo00O0O . replace ( 'w90' , 'w300_and_h450_bestv2' )
  i1111 = i1111 . replace ( '&#8211;' , '-' ) . replace ( '#038;' , '' ) . replace ( '\\xc3\\xa9' , 'e' ) . replace ( '&#8217;' , '\'' )
  o0oO0 ( '[B][COLOR white]%s[/COLOR][/B]' % i1111 , url , 100 , oOOoo00O0O , O00ooooo00 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 46 - 46: iII111ii % iII111ii - i11Ii11I1Ii1i * i1I1ii1II1iII % IIIII
def OOooO0OOoo ( url ) :
 o0oOoO00o = open_url ( url ) . content
 i1 = re . compile ( 'TV Shows</h3>(.+?)<footer class="main">' , re . DOTALL ) . findall ( o0oOoO00o )
 O0OoOoo00o = re . compile ( '<img src="(.+?)".+?<a href="(.+?)">(.+?)</a>' , re . DOTALL ) . findall ( str ( i1 ) )
 for oOOoo00O0O , url , i1111 in O0OoOoo00o :
  oOOoo00O0O = oOOoo00O0O . replace ( 'w90' , 'w300_and_h450_bestv2' )
  i1111 = i1111 . replace ( '&#8217;' , '' ) . replace ( '#038;' , '' ) . replace ( '\\xc3\\xa9' , 'e' ) . replace ( '&#039;' , '\'' )
  o0oO0 ( '[B][COLOR white]%s[/COLOR][/B]' % i1111 , url , 9 , oOOoo00O0O , O00ooooo00 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 29 - 29: i1I1ii1II1iII / ooOO00oOo
def IiIIIiI1I1 ( url ) :
 o0oOoO00o = open_url ( url ) . content
 i1 = re . compile ( 'class="item tvshows".+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"' , re . DOTALL ) . findall ( o0oOoO00o )
 for url , oOOoo00O0O , i1111 in i1 :
  oOOoo00O0O = oOOoo00O0O . replace ( 'w185' , 'w300_and_h450_bestv2' )
  i1111 = i1111 . replace ( '&#8217;' , '\'' )
  o0oO0 ( '[B][COLOR white]%s[/COLOR][/B]' % i1111 , url , 9 , oOOoo00O0O , O00ooooo00 , '' )
 i11 = re . compile ( 'class="current".+?<a href=\'(.+?)\'' , re . DOTALL ) . findall ( o0oOoO00o )
 for url in i11 :
  o0oO0 ( '[B][COLOR blue]Next Page>>>[/COLOR][/B]' , url , 8 , ooo0OO + 'nextpage.jpg' , O00ooooo00 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 86 - 86: i11iIiiIii + I1i1i1ii + iII111ii * oOo0oooo00o + i1I1ii1II1iII
def oOoO ( url ) :
 o0oOoO00o = open_url ( url ) . content
 i1 = re . compile ( '<div class="imagen">.+?<div class="numerando">(.+?)</div>.+?<a href="(.+?)">(.+?)</a>' , re . DOTALL ) . findall ( o0oOoO00o )
 for oOo , url , oOoOoO in i1 :
  i1111 = oOo + '   ' + oOoOoO
  i1111 = i1111 . replace ( '&#039;' , '\'' ) . replace ( 'amp;' , '' )
  o0oO0 ( '[B][COLOR white]%s[/COLOR][/B]' % i1111 , url , 100 , ii1I , O00ooooo00 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 76 - 76: O0 / i1I1ii1II1iII . iiiiIi11i * I1i1i1ii - O00o0o0000o0o
def Oooo ( url ) :
 o0oOoO00o = open_url ( url ) . content
 O00o = re . compile ( '<iframe.+?src="https://www.youtube.com/embed/(.+?)\?rel=0&amp;controls=1&amp;showinfo=0&autoplay=0"' , re . DOTALL ) . findall ( o0oOoO00o )
 for url in O00o :
  o0oO0 ( '[B][COLOR red]Play Trailer[/COLOR][/B]' , 'plugin://plugin.video.youtube/play/?video_id=%s' % url , 100 , ii1I , O00ooooo00 , i1111 )
 i1 = re . compile ( 'file: "(.+?)".+?label: "(.+?)"' , re . DOTALL ) . findall ( o0oOoO00o )
 for url , oOoOoO in i1 :
  o0oO0 ( '[B][COLOR white]%s[/COLOR][/B]' % oOoOoO , url , 100 , ii1I , O00ooooo00 , i1111 )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 61 - 61: IIIII . ooOO00oOo * iiiiIi11i . iII111ii % II11iiII
def oOo00Oo00O ( ) :
 iI11i1I1 = xbmc . Keyboard ( '' , 'Search' )
 iI11i1I1 . doModal ( )
 if ( iI11i1I1 . isConfirmed ( ) ) :
  o0o0OOO0o0 = iI11i1I1 . getText ( ) . replace ( ' ' , '+' )
  ooOOOo0oo0O0 = IIi1IiiiI1Ii + '/?s=' + o0o0OOO0o0
  o0 ( ooOOOo0oo0O0 )
  if 9 - 9: I1i1i1ii + i11Ii11I1Ii1i % I1i1i1ii + Ooo00oOo00o . O00o0o0000o0o
def o0 ( url ) :
 o0oOoO00o = open_url ( url ) . content
 i1 = re . compile ( '<div class="result-item">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"' , re . DOTALL ) . findall ( o0oOoO00o )
 for url , oOOoo00O0O , i1111 in i1 :
  i1111 = i1111 . replace ( '&#8217;' , '' ) . replace ( '#038;' , '' )
  oOOoo00O0O = oOOoo00O0O . replace ( 'w90' , 'w300_and_h450_bestv2' )
  if '/tvseries/' in url :
   o0oO0 ( '[B][COLOR white]%s[/COLOR][/B]' % i1111 , url , 9 , oOOoo00O0O , O00ooooo00 , '' )
  else :
   o0oO0 ( '[B][COLOR white]%s[/COLOR][/B]' % i1111 , url , 100 , oOOoo00O0O , O00ooooo00 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 31 - 31: i1I1ii1II1iII + oOo0oooo00o + oOo0oooo00o / oOoO0oo0OOOo
def iiI1 ( url ) :
 url = url . replace ( '?player=option-1' , '' )
 o0oOoO00o = open_url ( url ) . content
 try :
  url = re . compile ( 'https://redirector.googlevideo.com/(.+?)"' , re . DOTALL ) . findall ( o0oOoO00o ) [ 3 ]
  if 19 - 19: oOo0oooo00o + iII111ii
 except :
  url = re . compile ( 'https://redirector.googlevideo.com/(.+?)"' , re . DOTALL ) . findall ( o0oOoO00o ) [ - 1 ]
 url = 'https://redirector.googlevideo.com/' + url
 ooo = xbmcgui . ListItem ( i1111 , iconImage = "DefaultVideo.png" , thumbnailImage = ii1I )
 ooo . setInfo ( type = "Video" , infoLabels = { "Title" : ii1I1i1I } )
 ooo . setProperty ( "IsPlayable" , "true" )
 ooo . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooo )
 if 88 - 88: OoOO0ooOOoo0O + O0 / o0000oOoOoO0o * IIIII
 if 41 - 41: i11Ii11I1Ii1i
def ii1i1I1i ( ) :
 o00oOO0 = [ ]
 oOoo = sys . argv [ 2 ]
 if len ( oOoo ) >= 2 :
  iIii11I = sys . argv [ 2 ]
  OOO0OOO00oo = iIii11I . replace ( '?' , '' )
  if ( iIii11I [ len ( iIii11I ) - 1 ] == '/' ) :
   iIii11I = iIii11I [ 0 : len ( iIii11I ) - 2 ]
  Iii111II = OOO0OOO00oo . split ( '&' )
  o00oOO0 = { }
  for iiii11I in range ( len ( Iii111II ) ) :
   Ooo0OO0oOO = { }
   Ooo0OO0oOO = Iii111II [ iiii11I ] . split ( '=' )
   if ( len ( Ooo0OO0oOO ) ) == 2 :
    o00oOO0 [ Ooo0OO0oOO [ 0 ] ] = Ooo0OO0oOO [ 1 ]
 return o00oOO0
 if 50 - 50: iiiiIi11i
 if 34 - 34: iiiiIi11i * oOoO0oo0OOOo % IIIII * o0000oOoOoO0o - iiiiIi11i
def o0oO0 ( name , url , mode , iconimage , fanart , description ) :
 II1III = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 iI1iI1I1i1I = True
 ooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ooo . setProperty ( 'fanart_image' , fanart )
 if mode == 100 :
  ooo . setProperty ( "IsPlayable" , "true" )
  iI1iI1I1i1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1III , listitem = ooo , isFolder = False )
 else :
  iI1iI1I1i1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1III , listitem = ooo , isFolder = True )
 return iI1iI1I1i1I
 if 24 - 24: oooO0oo0oOOOO
 if 56 - 56: iII111ii
iIii11I = ii1i1I1i ( )
ooOOOo0oo0O0 = None
i1111 = None
o0O = None
ii1I = None
ii1I1i1I = None
if 72 - 72: IIIII / Ooo00oOo00o * II11iiII - iIIIiI11
if 51 - 51: oOoO0oo0OOOo * OoOO0ooOOoo0O % i1I1ii1II1iII * oOoO0oo0OOOo % oooO0oo0oOOOO / iII111ii
if 49 - 49: i1I1ii1II1iII
if 35 - 35: o0000oOoOoO0o - oOo0O0Ooo / oooO0oo0oOOOO % Ooo00oOo00o
try :
 ooOOOo0oo0O0 = urllib . unquote_plus ( iIii11I [ "url" ] )
except :
 pass
try :
 i1111 = urllib . unquote_plus ( iIii11I [ "name" ] )
except :
 pass
try :
 ii1I = urllib . unquote_plus ( iIii11I [ "iconimage" ] )
except :
 pass
try :
 o0O = int ( iIii11I [ "mode" ] )
except :
 pass
try :
 ii1I1i1I = urllib . unquote_plus ( iIii11I [ "description" ] )
except :
 pass
 if 78 - 78: oOo0oooo00o
if o0O == None or ooOOOo0oo0O0 == None or len ( ooOOOo0oo0O0 ) < 1 : O0oO ( )
elif o0O == 2 : OOooO0OOoo ( ooOOOo0oo0O0 )
elif o0O == 3 : I1 ( ooOOOo0oo0O0 )
elif o0O == 4 : i1iIIi1 ( ooOOOo0oo0O0 )
elif o0O == 5 : Ooo ( ooOOOo0oo0O0 )
elif o0O == 6 : oOo00Oo00O ( )
elif o0O == 7 : oo0Ooo0 ( ooOOOo0oo0O0 )
elif o0O == 8 : IiIIIiI1I1 ( ooOOOo0oo0O0 )
elif o0O == 9 : oOoO ( ooOOOo0oo0O0 )
elif o0O == 10 : Oooo ( ooOOOo0oo0O0 )
elif o0O == 100 : iiI1 ( ooOOOo0oo0O0 )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 71 - 71: O00o0o0000o0o + iII111ii % i11iIiiIii + oooO0oo0oOOOO - i111IiI
if 88 - 88: o0000oOoOoO0o - OoOO0ooOOoo0O % O00o0o0000o0o
if 16 - 16: iiiiIi11i * i11Ii11I1Ii1i % i111IiI
if 86 - 86: iiiiIi11i + I1i1i1ii % i11iIiiIii * i11Ii11I1Ii1i . iII111ii * oOo0oooo00o
if 44 - 44: i11Ii11I1Ii1i
if 88 - 88: iIIIiI11 % I1i1i1ii . oOoO0oo0OOOo
if 38 - 38: i1I1ii1II1iII
if 57 - 57: O0 / i11Ii11I1Ii1i * iIIIiI11 / o0000oOoOoO0o . oOoO0oo0OOOo
if 26 - 26: IIIII
if 91 - 91: OoOO0ooOOoo0O . oooO0oo0oOOOO + OoOO0ooOOoo0O - IIIII / oOo0O0Ooo
if 39 - 39: oooO0oo0oOOOO / iII111ii - oOoO0oo0OOOo
if 98 - 98: oooO0oo0oOOOO / oOo0oooo00o % i11Ii11I1Ii1i . o0000oOoOoO0o
if 91 - 91: i11Ii11I1Ii1i % II11iiII
if 64 - 64: oOo0oooo00o % IIIII - iIIIiI11 - i11Ii11I1Ii1i
if 31 - 31: oOo0oooo00o - oOoO0oo0OOOo . oOo0oooo00o
if 18 - 18: i1I1ii1II1iII
if 98 - 98: IIIII * IIIII / IIIII + oOo0oooo00o
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
