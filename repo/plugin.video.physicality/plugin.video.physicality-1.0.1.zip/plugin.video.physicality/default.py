# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Binky TV special thanks to original authors of the code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: Dandymedia
#------------------------------------------------------------

import os
import sys, dandy
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.physicality'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "UCBINFWq52ShSgUFEoynfSwg"
YOUTUBE_CHANNEL_ID_2 = "UCiP6wD_tYlYLYh3agzbByWQ"
YOUTUBE_CHANNEL_ID_3 = "UCD0nBMLdq_KbIK9u-mzpNkA"
YOUTUBE_CHANNEL_ID_4 = "UCulr-lJe8M6CcJTsxVGFoIw"
YOUTUBE_CHANNEL_ID_5 = "UCIJwWYOfsCfz6PjxbONYXSg"
YOUTUBE_CHANNEL_ID_6 = "UCuY1W4AwhhgkB6rsJBtltUA"
YOUTUBE_CHANNEL_ID_7 = "UCnUlSOVlCmoyQ6e2YQAGZZA"
YOUTUBE_CHANNEL_ID_8 = "UCM1Nde-9eorUhq-teaWlgUA"
YOUTUBE_CHANNEL_ID_9 = "UCgBTevPW8fsH4pQNrLufOsQ"
YOUTUBE_CHANNEL_ID_10 = "UCa5OCJkZgtbIkaB1sA86XVA"
YOUTUBE_CHANNEL_ID_11 = "UCTmAxqt83Eg-20ZUe8bfY3Q"
YOUTUBE_CHANNEL_ID_12 = "UCMTXToEZ6VT5k9GOCFNYjWA"
YOUTUBE_CHANNEL_ID_13 = "UCA9k6Z3B9ywXmwKh-zpBwfw"
YOUTUBE_CHANNEL_ID_14 = "UCRKUYrNScNNirPDO2VWqAIA"
YOUTUBE_CHANNEL_ID_15 = "UCmev1eHpKJ7HfQyV4Tm_qBg"
YOUTUBE_CHANNEL_ID_16 = "UCs3Z-fTqIZdcPd4u9U-LNaw"
YOUTUBE_CHANNEL_ID_17 = "UCjtBb0_nFqXdA762lferNaQ"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="POPSUGAR Fitness",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://yt3.ggpht.com/-BsrLTcw7rsg/AAAAAAAAAAI/AAAAAAAAAAA/e7g-a22BudQ/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="FitnessBlender",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://yt3.ggpht.com/-60HgUrZsM18/AAAAAAAAAAI/AAAAAAAAAAA/EhMzQ6LTPOk/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BeFit",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://yt3.ggpht.com/-H6YodrSuTiQ/AAAAAAAAAAI/AAAAAAAAAAA/mcMy87MgLEI/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GymRa",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/-P8EqM-wtzEU/AAAAAAAAAAI/AAAAAAAAAAA/vQQIEReUt3g/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Blogilates",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://yt3.ggpht.com/-706JtftpW58/AAAAAAAAAAI/AAAAAAAAAAA/5BwaDJDNZ6c/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BodyRock",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://yt3.ggpht.com/-79qJxGA4EhM/AAAAAAAAAAI/AAAAAAAAAAA/Nl9vF5phtUU/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="DietHealth",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://yt3.ggpht.com/-iw2O1WQf7pQ/AAAAAAAAAAI/AAAAAAAAAAA/N4nOfL-ITtY/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="XHIT Daily",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://yt3.ggpht.com/-3ALiD5ujWlI/AAAAAAAAAAI/AAAAAAAAAAA/N7Sph09ibuc/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Tone It Up",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://yt3.ggpht.com/-THpwFd3Eyvw/AAAAAAAAAAI/AAAAAAAAAAA/H53He1Wi6tA/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="TaraStiles",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://yt3.ggpht.com/-KVbgh-1YFdo/AAAAAAAAAAI/AAAAAAAAAAA/RGau2eFfMzE/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )                

    plugintools.add_item( 
        #action="", 
        title="Lauren Hefez",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://yt3.ggpht.com/-DbhceIoxaFU/AAAAAAAAAAI/AAAAAAAAAAA/XcqGNJb_x4A/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )    

    plugintools.add_item( 
        #action="", 
        title="Amanda Russel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://yt3.ggpht.com/-zv1pABrdF9A/AAAAAAAAAAI/AAAAAAAAAAA/CmgkMnA_b_Y/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="BodyFit By Amy",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://yt3.ggpht.com/-GFYjID3nGmY/AAAAAAAAAAI/AAAAAAAAAAA/m4lnqOeTSJg/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="Steadyhealth",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://yt3.ggpht.com/-LJYmrbOWwss/AAAAAAAAAAI/AAAAAAAAAAA/vKqGjU_RhkE/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True ) 
		
    plugintools.add_item( 
        #action="", 
        title="Jenny Ford",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://yt3.ggpht.com/-0ByhYYDTRCk/AAAAAAAAAAI/AAAAAAAAAAA/quwA7tco2KM/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="SparkPeople",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://yt3.ggpht.com/-NxYPrJjmGxo/AAAAAAAAAAI/AAAAAAAAAAA/xa0kZXTIUnM/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Sarah Fit",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://yt3.ggpht.com/-bzM275pLXh0/AAAAAAAAAAI/AAAAAAAAAAA/77kftcLZGHo/s500-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
				
run()		
